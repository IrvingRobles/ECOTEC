<link rel="stylesheet" href="css2/bootstrap.min.css">

<?php
sleep(1);

include 'db.php';
$nombre = $_GET['nombre'];
$usuario = $_GET['usuario'];
$correo = $_GET['correo'];
$contrasena = $_GET['contrasena'];

// echo $nombre, $correo, $contrasena, $usuario;

    $sql = "SELECT COUNT(*) AS correo_verificar FROM persona WHERE correo = '$correo'";
    $resultado = mysqli_query($conexion, $sql);
    $row = mysqli_fetch_assoc($resultado);

    if($row['correo_verificar']==0){

        $agregarnuevousuario = mysqli_query($conexion, "INSERT INTO persona(nombre, usuario, correo, contrasena) 
        VALUES ('$nombre', '$usuario', '$correo', '$contrasena')");
        
        if($agregarnuevousuario){
            echo '<div class="alert alert-success" role="alert">Usuario Registrado con exito podra <a href="login.php">Iniciar Sesion</a></div>' ;
        }
    }else{
        echo '<div class="alert alert-danger" role="alert">Error el correo '.$correo.' Ya esta en nuestra base de datos.</div>' ;
        echo '<img src="img/ECOTEC_LOGO1.1.png" alt="error" width="200px" height="100px">';
        echo '<br>';
        echo '<a class="btn btn-success" href="login.php">Iniciar Sesion</a>';

    }

?>

