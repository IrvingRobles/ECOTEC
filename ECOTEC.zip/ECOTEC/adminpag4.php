<?php include 'sesiones.php'; ?>
<?php include 'db.php'; ?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="css2/estilo.css">
  <link rel="stylesheet" href="css2/login.css">
  <script src="js/jquery.min.js"></script>

  <title>Agrega mi Empresa</title>
  <script>
    $(document).ready(function() {
      $('#registrarempresa').submit(function(e) {
        e.preventDefault();

        document.getElementById("mensajeempresa").innerHTML = "";
        var BtnGuardar = $("#BtnGuardar");
        $.ajax({
          data: $('#registrarempresa').serialize(),
          url: 'procesar2.php',
          type: 'post',
          beforeSend: function() {
            $("#BtnGuardar").text("Guardando...");
          },
          complete: function(data) {
            var resp = data.responseText;
            BtnGuardar.text("Guardar mi empresa");
          },
          success: function(respuesta) {
            setTimeout(function() {
              document.getElementById('resultadoempresa').style.display = 'none';
            }, 2000);
            document.getElementById('resultadoempresa').style.display = 'block';
            $('#mensajeempresa').html(respuesta);
          },
        });
      });
    });
  </script>
  <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <!-- Estilos adicionales para el mapa -->
  <style>
    #mapa {
      /* Estilo para el contenedor del mapa */
      height: 550px;
      width: 550px;
    }
  </style>
</head>

<body class="bodyp">
  <?php include 'templates/header2.php' ?>



  <div class="container text-center">

    <div class="row">
      <div class="col-0"></div>
      <div class=" formulario">
        <label class='text1 label1'>
          <h2 class="tituloh2 text1">Registro de Empresa</h2>
          <!-- <button type="button" class="nav2" style="border: none;" onclick="sound8.play()"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" fill="currentColor" class="bi bi-volume-up-fill" viewBox="0 0 16 16">
              <path d="M11.536 14.01A8.473 8.473 0 0 0 14.026 8a8.473 8.473 0 0 0-2.49-6.01l-.708.707A7.476 7.476 0 0 1 13.025 8c0 2.071-.84 3.946-2.197 5.303l.708.707z" />
              <path d="M10.121 12.596A6.48 6.48 0 0 0 12.025 8a6.48 6.48 0 0 0-1.904-4.596l-.707.707A5.483 5.483 0 0 1 11.025 8a5.483 5.483 0 0 1-1.61 3.89l.706.706z" />
              <path d="M8.707 11.182A4.486 4.486 0 0 0 10.025 8a4.486 4.486 0 0 0-1.318-3.182L8 5.525A3.489 3.489 0 0 1 9.025 8 3.49 3.49 0 0 1 8 10.475l.707.707zM6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z" />
            </svg></button> -->
          <form class="contenedor" id="registrarempresa">

            <!-- Contenedor del mapa -->
            <center>
              <div id="mapa"></div>
            </center>
            <br>
            <input type="hidden" class="form-control" id="coordenadas" name="coordenadas" placeholder="Coordenadas seleccionadas">
            <label class='text1' for="nombre">Nombre de la Empresa:</label>
            <input class='form-control' type="text" id="nombre" name="nombre" required><br><br>
            <input class='form-control' type="hidden" id="id_persona" name="id_persona" value="<?php echo $_SESSION['id'] ?>">
            <input class='form-control' type="hidden" id="usuario" name="usuario" value="<?php echo $_SESSION['usuario'] ?>">

            <label class='text1' for="municipio">Municipio:</label>
            <select id="municipio" name="municipio" class="form-control">
              <option class='text1' value="Nanchital">NANCHITAL</option>
              <option class='text1' value="IXHUATLAN">IXHUATLAN</option>
              <option class='text1' value="Coatzacoalcos">COATZACOALCOS</option>
            </select><br><br>

            <label class='text1' for="direccion">Dirección:</label>
            <input class='form-control' type="text" id="direccion" name="direccion" required><br><br>

            <label class='text1' for="telefono">Teléfono (10 dígitos numéricos):</label>
            <input class='form-control' type="tel" id="telefono" name="telefono" pattern="[0-9]{10}" required><br><br>

            <label class='text1'>Días de la semana que labora:</label><br>
            <input class='text1' type="checkbox" id="lunes" name="dias[]" value="lunes">
            <label class='text1' for="lunes">Lunes</label><br>
            <input class='text1' type="checkbox" id="martes" name="dias[]" value="martes">
            <label class='text1' for="martes">Martes</label><br>
            <input class='text1' type="checkbox" id="miercoles" name="dias[]" value="miercoles">
            <label class='text1' for="miercoles">Miércoles</label><br>
            <input class='text1' type="checkbox" id="jueves" name="dias[]" value="jueves">
            <label class='text1' for="jueves">Jueves</label><br>
            <input class='text1' type="checkbox" id="viernes" name="dias[]" value="viernes">
            <label class='text1' for="viernes">Viernes</label><br>
            <input class='text1' type="checkbox" id="sabado" name="dias[]" value="sabado">
            <label class='text1' for="sabado">Sábado</label><br>
            <input class='text1' type="checkbox" id="domingo" name="dias[]" value="domingo">
            <label class='text1' for="domingo">Domingo</label><br><br>

            <label class='text1' for="horario">Horario de Atención (formato 24 horas):</label>
            <input class='text1' type="text" id="horario" name="horario" placeholder="Ejemplo: 08:00 - 18:00" required><br><br>

            <button type="submit" class="btn btn-success" id="BtnGuardar">Guardar mi empresa</button>
            
            <!-- ALERTA DE CORREO -->
            <div id="resultadoempresa" style="display:none;">
              <div id="mensajeempresa"></div>
            </div>
          </form>
          



        </label>
      </div>
      <div class="col-0"></div>
    </div>
  </div>


  <!-- Incluir la biblioteca de Leaflet -->
  <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

  <script>
    // Inicializar el mapa
    var mapa = L.map('mapa').setView([18.04834, -94.40237], 13);

    // Añadir una capa de mosaico (tile layer)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(mapa);

    // Inicializar el marcador con una posición inicial
    var marcador = L.marker([18.04834, -94.40237]).addTo(mapa);

    // Función para actualizar la posición del marcador y el input con las coordenadas
    function actualizarPosicionMarcador(e) {
      marcador.setLatLng(e.latlng);
      document.getElementById('coordenadas').value = e.latlng.lat.toFixed(5) + ', ' + e.latlng.lng.toFixed(5);
    }

    // Asignar el evento de clic en el mapa para actualizar la posición del marcador
    mapa.on('click', actualizarPosicionMarcador);
  </script>
  <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
  <script src="audios.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <?php include 'templates/footer.php' ?>

</body>