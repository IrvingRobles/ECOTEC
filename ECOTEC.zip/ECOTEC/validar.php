<?php

include('db.php');

$USUARIO=$_POST['usuario'];
$PASSWORD=$_POST['contrasena'];


$consulta = "SELECT* FROM Persona where usuario = '$USUARIO' and contrasena ='$PASSWORD' ";
$resultado= mysqli_query($conexion, $consulta);

$filas=mysqli_num_rows($resultado);

if($filas){
    header("location:usuariosAdmin.php");

}else{
    include("002.php");
    ?>
    <!-- <h1>ERROR DE AUTENTIFICACION</h1> -->
    <?php
    
}
mysqli_free_result($resultado);
mysqli_close($conexion);





?>