<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estados y Municipios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        h1 {
            text-align: center;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div id="app">
        <h1>Estados y Municipios</h1>
        <select id="states"></select>
        <select id="cities"></select>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const statesSelect = document.getElementById('states');
            const citiesSelect = document.getElementById('cities');

            // Aquí debes reemplazar 'URL_DE_TU_API_DE_ESTADOS' y 'URL_DE_TU_API_DE_MUNICIPIOS' con las URLs reales de las API que proporcionan datos de estados y municipios, respectivamente.
            // Hacer una solicitud a la API para obtener la lista de estados
            fetch(' https://datos-abiertos.edomex.gob.mx/index.php/estados/csv')
                .then(response => response.json())
                .then(data => {
                    // Iterar sobre los estados y agregarlos al select
                    data.forEach(state => {
                        const option = document.createElement('option');
                        option.textContent = state.name;
                        option.value = state.id;
                        statesSelect.appendChild(option);
                    });
                });

            // Escuchar los cambios en el select de estados
            statesSelect.addEventListener('change', function() {
                const selectedStateId = this.value;

                // Hacer una solicitud a la API para obtener los municipios del estado seleccionado
                fetch(`estados.json?stateId=${selectedStateId}`)
                    .then(response => response.json())
                    .then(data => {
                        // Limpiar el select de municipios
                        citiesSelect.innerHTML = '';

                        // Iterar sobre los municipios y agregarlos al select
                        data.forEach(city => {
                            const option = document.createElement('option');
                            option.textContent = city.name;
                            option.value = city.id;
                            citiesSelect.appendChild(option);
                        });
                    });
            });
        });
    </script>
</body>
</html>
