<style>
    /* Borrar los márgenes y el relleno por defecto del cuerpo */
    body {
        margin: 0;
        padding: 0;
    }

    /* Estilo básico para el botón del menú desplegable */
    .dropbtn {
        background-color: #3498db;
        color: white;
        padding: 10px;
        font-size: 16px;
        border: none;
        cursor: pointer;
    }

    /* Estilo para la posición del contenedor del menú desplegable */
    .dropdown {
        position: relative;
        display: inline-block;
    }

    /* Estilo para el contenido del menú desplegable (inicialmente oculto) */
    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    /* Estilo para los enlaces dentro del menú desplegable */
    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    /* Cambiar el color del enlace al pasar el ratón sobre él */
    .dropdown-content a:hover {
        background-color: rgba(6, 135, 6, 0.873);
        color: white;
    }

    /* Mostrar el contenido del menú desplegable al pasar el ratón sobre el botón */
    .dropdown:hover .dropdown-content {
        display: block;
    }
</style>

<nav class="navbar navbar-expand-lg badge nav4" ;>
    <div class="container-fluid">
        <a href="usuariosAdmin.php"><img class="logo" src="img/ECOTEC_LOGO1.1.png" alt="">
        </a>

        <a class="navbar-brand nav2 letra1 text1" href="adminpag6.php">CONOCE <br>ECOTEC</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link nav2" href="adminpag3.php"><img mg class="icono3" src="img\drive-download-20231016T014448Z-001\inforrmacion.png" alt=""></a>
                </li>

                <li class="nav-item">
                    <a class="nav-link nav2" href="adminpag5.php"> <img class="icono3" src="img\drive-download-20231016T014448Z-001\dibujoedificio1.png" alt=""></a>
                </li>

                <li class="nav-item">
                </li>
                <li class="nav-item">
                    <a class="nav-link nav2" href="adminpag4.php">REGISTRA <br>MI EMPRESA</a>
                </li>
                <li class="nav-item">
                    <div class="dropdown">

                        <a class="nav-link nav2 text1">
                            <svg xmlns="http://www.w3.org/2000/svg" width="50" height="50" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0" />
                            </svg>
                        </a>
                        <div class="dropdown-content">
                            <a id="zoomInButton" class="btn colorletra text1" onclick="zoomText(true)">

                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                                    <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                                    <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z" />
                                </svg>
                            </a>
                            <a id="zoomOutButton" class="btn colorletra text1" onclick="zoomText(false)">

                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-out" viewBox="0 0 16 16">
                                    <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                                    <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                                    <path fill-rule="evenodd" d="M3 6.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z" />
                                </svg>
                            </a>
                        </div>
                    </div>

                </li>
                <li class="nav-item">
                    <a class="nav-link nav2" href="login.php">Cerrar Sesión</a>
                </li>


            </ul>
        </div>
    </div>
</nav>
<div class="btn-group">
    <li class="btn text1 knowledge_text">
        <div id="contador-inactividad"></div>
    </li>
</div>