<script src="js/hacerzoom.js"></script>
<script src="js/cerrarsesion.js"></script>
