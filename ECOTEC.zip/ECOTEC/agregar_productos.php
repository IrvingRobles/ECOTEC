<?php
include 'db.php';

// Obtener el ID de la empresa desde la URL
if (isset($_GET['id'])) {
  $empresa_id = $_GET['id'];
} else {
  die("ID de empresa no especificado.");
}

// Consulta SQL para obtener información de la empresa seleccionada
$sql_empresa = "SELECT * FROM empresas WHERE id = $empresa_id";
$result_empresa = $conexion->query($sql_empresa);

// Verificar si la empresa existe
if ($result_empresa->num_rows == 0) {
  die("Empresa no encontrada.");
}

$empresa = $result_empresa->fetch_assoc();

// Procesar el formulario de adición de productos
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nombre_producto = $_POST['nombre_producto'];
  $precio_producto = $_POST['precio_producto'];

  // Consulta SQL para insertar el producto en la base de datos
  $sql_producto = "INSERT INTO productos (nombre, precio, empresa_id) VALUES ('$nombre_producto', '$precio_producto', '$empresa_id')";

  if ($conexion->query($sql_producto) === TRUE) {
    echo "Producto agregado exitosamente.";
  } else {
    echo "Error al agregar el producto: " . $conexion->error;
  }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="css2/estilo.css">
  <title>RECICLADORES Y RECOGIDAS FUERA DEL HOGAR</title>
</head>

<body class="bodyp">
<?php include 'templates/header2.php' ?>
  


  <div class="container text-center">

    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <h2 class="tituloh2"></h2>
        <label for="" class="label1">
          <h1 class="text1">Agregar Productos a <?php echo $empresa['nombre']; ?></h1>

          <h2 class="tituloh2 text1">Información de la Empresa:</h2>
          <p class="text1"><strong>Nombre:</strong> <?php echo $empresa['nombre']; ?></p>
          <p class="text1"><strong>Municipio:</strong> <?php echo $empresa['municipio']; ?></p>
          <p class="text1"><strong>Dirección:</strong> <?php echo $empresa['direccion']; ?></p>
          <p class="text1"><strong>Teléfono:</strong> <?php echo $empresa['telefono']; ?></p>
          <p class="text1"><strong>Días Laborales:</strong> <?php echo $empresa['dias_laborales']; ?></p>
          <p class="text1"><strong>Horario:</strong> <?php echo $empresa['horario']; ?></p>

          <h2 class="tituloh2 text1">Agregar Producto:</h2>
          <form action="" method="POST">
            <label class="text1" for="nombre_producto">Nombre del Producto:</label>
            <input class="text1" type="text" id="nombre_producto" name="nombre_producto" required><br><br>

            <label class="text1" for="precio_producto">Precio del Producto:</label>
            <input class="text1" type="number" id="precio_producto" name="precio_producto" step="0.01" required><br><br>

            <input class="text1" type="submit" value="Agregar Producto">
          </form>

          <br>

        </label>
      </div>
      <div class="col-2"></div>
    </div>
  </div>



  <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
<?php include 'templates/footer.php' ?>

</body>

</html>
<?php
// Cerrar la conexión a la base de datos
$conexion->close();
?>