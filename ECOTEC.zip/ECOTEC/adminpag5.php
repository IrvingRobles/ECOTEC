<?php include 'sesiones.php'; ?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/estilo.css">
    <title>EMPRESAS</title>
</head>

<body class="bodyp">
    <?php include 'templates/header2.php' ?>


    <div class="container text-center">

        <div class="row">
            <div class="col-1"></div>
            <div class="col-10">
                <h2 class="tituloh2 tabla">CONOCE LAS EMPRESAS</h2>

                <style>
                    /* Estilo para la tabla */
                    table {
                        border-collapse: collapse;
                        width: 100%;
                        max-width: 1050px;
                        margin: 0 auto;
                        background-color: #fff;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
                        border-radius: 10px;
                        overflow: hidden;
                    }

                    /* Estilo para las celdas de la tabla */
                    td,
                    th {
                        text-align: left;
                        padding: 8px;
                        font-size: 16px;
                        font-weight: normal;
                        border-bottom: 1px solid #ddd;
                    }

                    /* Estilo para el encabezado de la tabla */
                    th {
                        background-color: #f2f2f2;
                        font-weight: bold;
                    }

                    /* Estilo para las filas pares de la tabla */
                    tr:nth-child(even) {
                        background-color: #f9f9f9;
                    }

                    /* Estilo para las acciones de la tabla */
                    td:last-child {
                        text-align: center;
                    }

                    td a {
                        display: inline-block;
                        padding: 5px 10px;
                        color: #fff;
                        background-color: #4CAF50;
                        border-radius: 5px;
                        text-decoration: none;
                    }

                    td a+a {
                        margin-left: 10px;
                        margin-top: 5px;
                        background-color: #f44336;
                    }

                    /* Estilo para los botones hover de la tabla */
                    td a:hover {
                        background-color: #3e8e41;
                    }

                    td a+a:hover {
                        background-color: #e53935;
                    }

                    .bt {
                        background-color: #3e8e41;
                    }

                    .bt a+a:hover {
                        background-color: #e53935;
                    }



                    .eliminar {
                        background-color: rgb(246, 31, 31);

                    }
                </style>
                <!-- Estilos adicionales para el mapa -->
                <style>
                    #mapa {
                        /* Estilo para el contenedor del mapa */
                        height: 350px;
                        width: 350px;
                    }
                </style>
                <?php
                include 'db.php';

                // Consulta SQL para obtener la lista de empresas registradas
                $sql = "SELECT * FROM empresas WHERE id_persona = '{$_SESSION['id']}'";
                $result = $conexion->query($sql);
                ?>

                <!DOCTYPE html>
                <html>

                <head>
                    <link rel="stylesheet" href="css2/estilo.css">

                    <title>Lista de Empresas Registradas</title>

                </head>

                <body>

                    <?php


                    if ($result->num_rows > 0) {
                        echo "<table border='1'>
                        <tr>
                            <th class='text1'>Usuario</th>
                            <th class='text1'>Nombre</th>
                            <th class='text1'>Municipio</th>
                            <th class='text1'>Dirección</th>
                            <th class='text1'>Detalles de la empresa</th>
                            <th class='text1'></th>
                        </tr>";

                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                            <td class='text1'>" . $row["usuario"] . "</td>
                            <td class='text1'>" . $row["nombre"] . "</td>
                            <td class='text1'>" . $row["municipio"] . "</td>
                            <td class='text1'>" . $row["direccion"] . "</td>
                            <td class='text1'><a href='adminDetalle.php?id=" . $row["id"] . "'>Detalles</a> <a class='bt'href='agregar_productos.php?id=" . $row["id"] . "'>+</a></td>
                            
                            <td class='text1'><a class='eliminar' href='eliminar.php?id=" . $row["id"] . "'>Eliminar</a></td>
                            
                        </tr>";
                        }

                        echo "</table>";
                    } else {
                        echo "No hay empresas registradas.";
                    }


                    ?>

                    <br>
                </body>

                </html>

                <?php
                // Cerrar la conexión a la base de datos
                $conexion->close();
                ?>



            </div>




        </div>



        <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <?php include 'templates/footer.php' ?>

</body>

</html>