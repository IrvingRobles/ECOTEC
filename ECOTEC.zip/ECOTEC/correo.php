<?php
sleep(1);

$nombre = $_POST['nombre'];
$usuario = $_POST['usuario'];
$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];

$asunto = "Verificar Datos";
$mensaje = '

    <html>

        <head>
            <style>
                body {
                    font-family: "Quicksand", sans-serif;
                    background-color: #f5f5f5;
                    margin: 0;
                    padding: 20px;
                }

                .container {
                    background-color: rgba(139, 171, 241, 0.284);

                    border-radius: 5px;
                    padding: 20px;
                    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.1);
                }

                .header {
                    color: black;
                    padding: 10px;
                    text-align: center;
                }
                p{
                    text-align: center;
                }

                table {
                border-collapse: collapse;
                width: 100%;
                margin: auto;
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 8px 15px;
                    text-align: left;
                }
                th {
                    background-color: white;
                    color: black;
                }
                h1{
                    text-decoration: none;
                }
                .btn-success {
                    color: #fff;
                    background-color: #28a745;
                    border-color: #28a745;
                }
                .btn {
                display: inline-block;
                font-weight: 400;
                text-align: center;
                white-space: nowrap;
                vertical-align: middle;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
                user-select: none;
                border: 1px solid transparent;
                padding: .375rem .75rem;
                font-size: 1rem;
                line-height: 1.5;
                border-radius: .25rem;
                transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
            }
            a{
                text-decoration: none;
                color: white;
            }

            </style>
        </head>

        <body>
            <div class="container">
                <div class="header">
                    <h1>Registro Exitoso</h1>
                    <img src="https://lh3.google.com/u/0/d/11CrEdNeKKtdTMQ-Jf98PO--IistKF9As=w1358-h620-iv1" alt="error" width="200px" height="100px">
                    <p>Hola: <b>' . $nombre.'</b></p>
                    <table>
                        <tr>
                            <th>Datos</th>
                            <th>Datos Registrados</th>
                        </tr>
                        <tr>
                            <td>Nombre</td>
                            <td>'.$nombre.'</td>
                        </tr>
                        <tr>
                            <td>Usuario</td>
                            <td>'.$usuario.'</td>
                        </tr>
                        <tr>
                            <td>Correo Electronico</td>
                            <td>'.$correo.'</td>
                        </tr>
                        <tr>
                            <td>Contraseña</td>
                            <td>'.$contrasena.'</td>
                        </tr>
                    </table>
                    <a href="http://localhost/ECOTEC/validarregistro.php?nombre='.$nombre.'&&usuario='.$usuario.'&&correo='.$correo.'&&contrasena='.$contrasena.'" class="btn btn-success">Validar Datos</a>
                    <p>¡Gracias por Registrarte!</p>
                </div>
            </div>
        </body>

    </html>

';
$cabeceras  = 'MIME-Version: 1.0' . "\r\n";
$cabeceras .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Cabeceras adicionales
// dirección del remitente
$cabeceras .= "From: ECOTEC <irving.rob0605@gmail.com>\r\n"; 

    if(mail($correo, $asunto, $mensaje, $cabeceras)){
        echo '<div class="alert alert-success" role="alert">Correo enviado con exito</div>' ;
    }else{
        echo '<div class="alert alert-danger" role="alert">Error al enviar el correo</div>' ;

    }
?>

