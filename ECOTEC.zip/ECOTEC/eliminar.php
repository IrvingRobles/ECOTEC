<?php
// Conexión a la base de datos
$servername = "localhost"; // Nombre del servidor de la base de datos
$username = "root"; // Nombre de usuario de la base de datos
$password = "mamalopa"; // Contraseña de la base de datos
$dbname = "validar"; // Nombre de la base de datos

// Crear una conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener el ID de la empresa desde la URL
if (isset($_GET['id'])) {
    $empresa_id = $_GET['id'];
} else {
    die("ID de empresa no especificado.");
}

// Consulta SQL para eliminar la empresa y sus productos asociados
$sql_eliminar_productos = "DELETE FROM productos WHERE empresa_id = $empresa_id";
if ($conn->query($sql_eliminar_productos) === TRUE) {
    $sql_eliminar_empresa = "DELETE FROM empresas WHERE id = $empresa_id";
    if ($conn->query($sql_eliminar_empresa) === TRUE) {
      header("Location: adminpag5.php");
      exit();
    } else {
        echo "Error al eliminar la empresa: " . $conn->error;
    }
} else {
    echo "Error al eliminar los productos: " . $conn->error;
}
?>



<?php
// Cerrar la conexión a la base de datos
$conn->close();
?>
