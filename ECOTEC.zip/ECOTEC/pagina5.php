<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="css2/estilo.css">
  <title>EMPRESAS</title>
</head>

<body class="bodyp">
<?php include 'templates/header.php' ?>


  <div class="container text-center">

    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <h2 class="tituloh2 text1">CONOCE LAS EMPRESAS</h2>

        <!-- <div class="card cards" style="width: 18rem;">
                  <img src="..." class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title">MEDESUR</h5>
                    <p class="card-text">Puerto México, 96510 Coatzacoalcos, Ver <br> LUNES A VIERNES <br>
                      8:00 AM A 18:00 PM</p>
                    <a href="#" class="btn btn-primary">Ver ubicacion</a>
                  </div> -->


      </div>
      <?php
      // // Conexión a la base de datos
      // $servername = "localhost"; // Nombre del servidor de la base de datos
      // $username = "root"; // Nombre de usuario de la base de datos
      // $password = ""; // Contraseña de la base de datos
      // $dbname = "validar"; // Nombre de la base de datos

      // // Crear una conexión a la base de datos
      // $conn = new mysqli($servername, $username, $password, $dbname);

      // // Verificar la conexión
      // if ($conn->connect_error) {
      //   die("Error de conexión: " . $conn->connect_error);
      // }
      include 'db.php';

      // Consulta SQL para obtener la lista de empresas registradas
      $sql = "SELECT * FROM empresas";
      $result = $conexion->query($sql);
      ?>

      <!DOCTYPE html>
      <html>

      <head>
        <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
        <link rel="stylesheet" href="css2/estilo.css">

        <title>Lista de Empresas Registradas</title>

      </head>

      <body>
        <style>
          /* Estilo para la tabla */
          table {
            border-collapse: collapse;
            width: 100%;
            max-width: 1050px;
            margin: 0 auto;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            border-radius: 10px;
            overflow: hidden;
          }

          /* Estilo para las celdas de la tabla */
          td,
          th {
            text-align: left;
            padding: 8px;
            font-size: 16px;
            font-weight: normal;
            border-bottom: 1px solid #ddd;
          }

          /* Estilo para el encabezado de la tabla */
          th {
            background-color: #f2f2f2;
            font-weight: bold;
          }

          /* Estilo para las filas pares de la tabla */
          tr:nth-child(even) {
            background-color: #f9f9f9;
          }

          /* Estilo para las acciones de la tabla */
          td:last-child {
            text-align: center;
          }

          td a {
            display: inline-block;
            padding: 5px 10px;
            color: #fff;
            background-color: #4CAF50;
            border-radius: 5px;
            text-decoration: none;
          }

          td a+a {
            margin-left: 10px;
            margin-top: 5px;
            background-color: #f44336;
          }

          /* Estilo para los botones hover de la tabla */
          td a:hover {
            background-color: #3e8e41;
          }

          td a+a:hover {
            background-color: #e53935;
          }
        </style>

        <?php


        if ($result->num_rows > 0) {
          echo "<table border='2' color='rgb(5, 99, 5)' class='text1'>
        <tr>
            <th class='text1'>Nombre</th>
            <th class='text1'>Municipio</th>
            <th class='text1'>Dirección</th>
            <th class='text1'>Teléfono</th>
            <th class='text1'>Días Laborales</th>
            <th class='text1'>Horario</th>
            <th class='text1'>Productos</th>
        </tr>";

          while ($row = $result->fetch_assoc()) {
            echo "<tr>
            <td class='text1'>" . $row["nombre"] . "</td>
            <td class='text1'>" . $row["municipio"] . "</td>
            <td class='text1'>" . $row["direccion"] . "</td>
            <td class='text1'>" . $row["telefono"] . "</td>
            <td class='text1'>" . $row["dias_laborales"] . "</td>
            <td class='text1'>" . $row["horario"] . "</td>
            <td class='text1'><a href='detalle.php?id=" . $row["id"] . "'> Detalle</a></td>            
        </tr>";
          }

          echo "</table>";
        } else {
          echo "No hay empresas registradas.";
        }


        ?>

        <br>
        <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
      </body>

      </html>

      <?php
      // Cerrar la conexión a la base de datos
      $conexion->close();
      ?>

    </div>



    <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  <?php include 'templates/footer.php' ?>

</body>

</html>