<?php 

include("db.php");

if (isset($_POST['register'])) {
    if (strlen($_POST['usuario']) >= 1 && strlen($_POST['pass']) >= 1) {
	    $usuario = trim($_POST['usuario']);
	    $password = trim($_POST['pass']);
	    
	    $consulta = "INSERT INTO datos(usuario, pass) VALUES ('$usuario','$password')";
        $resultado= mysqli_query($conexion, $consulta);
	    if ($resultado) {
	    	?> 
	    	<h3 class="ok">¡Te has inscripto correctamente!</h3>
           <?php
	    } else {
	    	?> 
	    	<h3 class="bad">¡Ups ha ocurrido un error!</h3>
           <?php
	    }
    }   else {
	    	?> 
	    	<h3 class="bad">¡Por favor complete los campos!</h3>
           <?php
    }
}

?>
