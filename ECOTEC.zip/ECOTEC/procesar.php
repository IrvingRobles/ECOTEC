<?php
// Conexión a la base de datos
$servername = "localhost"; // Nombre del servidor de la base de datos
$username = "root"; // Nombre de usuario de la base de datos
$password = "mamalopa"; // Contraseña de la base de datos
$dbname = "validar"; // Nombre de la base de datos

// Crear una conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener los datos del formulario (asegúrate de validarlos)
$nombre = mysqli_real_escape_string($conn, $_POST['nombre']);
$municipio = mysqli_real_escape_string($conn, $_POST['municipio']);
$direccion = mysqli_real_escape_string($conn, $_POST['direccion']);
$telefono = mysqli_real_escape_string($conn, $_POST['telefono']);
$horario = mysqli_real_escape_string($conn, $_POST['horario']);

// Procesar los días laborales
$dias_laborales = implode(", ", $_POST['dias']);

// Consulta SQL para insertar los datos en la tabla "empresas" (usando sentencias preparadas para mayor seguridad)
$sql = "INSERT INTO empresas (nombre, municipio, direccion, telefono, dias_laborales, horario) VALUES (?, ?, ?, ?, ?, ?)";

if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("ssssss", $nombre, $municipio, $direccion, $telefono, $dias_laborales, $horario);
    if ($stmt->execute()) {
        // Obtener coordenadas de Google Maps
        $ubicacioncompleta = $direccion . ", " . $municipio . ", Veracruz";
        $url = 'https://maps.googleapis.com/maps/api/geocode/json?address=' . urlencode($ubicacioncompleta) . '&key=AIzaSyCOAs_Y6KWMgc__aRTyHnwT3bEoi882Las';
        $json = file_get_contents($url);
        $data = json_decode($json);

        if ($data->status == "OK") {
            $lat = $data->results[0]->geometry->location->lat;
            $lng = $data->results[0]->geometry->location->lng;

            // Insertar coordenadas en la tabla "maps"
            $insertar_maps = "INSERT INTO maps (nombre, latitud, longitud) VALUES (?, ?, ?)";
            if ($stmt = $conn->prepare($insertar_maps)) {
                $stmt->bind_param("sdd", $nombre, $lat, $lng);
                if ($stmt->execute()) {
                    header("Location: pagina5.php");
                    exit();
                } else {
                    echo "Error al insertar coordenadas: " . $stmt->error;
                }
            } else {
                echo "Error de preparación de la consulta para insertar coordenadas: " . $conn->error;
            }
        } else {
            echo "Error en la solicitud de Google Maps: " . $data->status;
        }
    } else {
        echo "Error al registrar la empresa: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Error de preparación de la consulta: " . $conn->error;
}

// Cerrar la conexión a la base de datos
$conn->close();
?>
