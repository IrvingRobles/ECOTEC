<?php
// Conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "validar";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si se han enviado los datos
if (isset($_POST['nombre']) && isset($_POST['direccion']) && isset($_POST['ciudad']) && isset($_POST['horario']) && isset($_POST['correo']) && isset($_POST['telefono'])) {
  
  // Obtener los datos del formulario
  $idEmpresa = $_POST['id'];
  $nombre = $_POST['nombre'];
  $direccion = $_POST['direccion'];
  $ciudad = $_POST['ciudad'];
  $horario = $_POST['horario'];
  $correo = $_POST['correo'];
  $telefono = $_POST['telefono'];
  
  // Actualizar los datos de la empresa en la base de datos
  $sql = "UPDATE listaempresas SET nombre='$nombre', direccion='$direccion', ciudad='$ciudad', horarioAtencion='$horario', correo='$correo', telefono='$telefono' WHERE idEmpresa=$idEmpresa";
  
  if ($conn->query($sql) === TRUE) {
    // Redirigir de vuelta a la página de inicio con un mensaje de éxito
    header("Location: adminpag5.php");
    exit();
  } else {
    // Mostrar un mensaje de error si la consulta falló
    echo "Error al actualizar los datos: " . $conn->error;
  }
  
}

// Cerrar la conexión
$conn->close();
?>
