<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="css2/estilo.css">
  <title>El proceso del reciclaje</title>
</head>

<body class="bodyp" >
<?php include 'templates/header.php' ?>



  <div class="container text-center" >

    <div class="row">
      <div class="col-1"></div>
      <div class="col-10">
        <h2 id="miTexto" class="tituloh2 text1">EL PROCESO DEL RECICLAJE</h2>
        <button type="button" class="nav2" style="border: none;" onclick="sound7.play()"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" fill="currentColor" class="bi bi-volume-up-fill" viewBox="0 0 16 16">
            <path d="M11.536 14.01A8.473 8.473 0 0 0 14.026 8a8.473 8.473 0 0 0-2.49-6.01l-.708.707A7.476 7.476 0 0 1 13.025 8c0 2.071-.84 3.946-2.197 5.303l.708.707z" />
            <path d="M10.121 12.596A6.48 6.48 0 0 0 12.025 8a6.48 6.48 0 0 0-1.904-4.596l-.707.707A5.483 5.483 0 0 1 11.025 8a5.483 5.483 0 0 1-1.61 3.89l.706.706z" />
            <path d="M8.707 11.182A4.486 4.486 0 0 0 10.025 8a4.486 4.486 0 0 0-1.318-3.182L8 5.525A3.489 3.489 0 0 1 9.025 8 3.49 3.49 0 0 1 8 10.475l.707.707zM6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z" />
          </svg></button>
        <label for="" class="label1">

          <!-- <img src="img/1.png" class="IMGP3" alt=""> -->

          <!-- <table class="table tabla1">

            <tbody>
              <tr>
                <td></td>
                <td>Ciclo de vida de los envases  </td>
                <td></td>
                
              </tr>
              <tr>
                <td>Ciclo de vida de papel y cartón  </td>
                <td></td>
                <td><a href="" class="linkTabla">ver</a></td>
                
                
              </tr>
              <tr> 
                <td>Ciclo de vida de envases  </td>
                <td></td>
                <td><a href="" class="linkTabla">ver</a></td>
                
              </tr>
   
                <tr>
                  <td></td>
                  <td>Proceso de reciclaje de envases según su material </td>
                  <td></td>
                </tr>
                <tr>
                  <td>PET </td>
                  <td></td>
                  <td><a href="" class="linkTabla">ver</a></td>
  
                </tr>
                <tr>
                  <td>METAL  </td>
                  <td></td>
                  <td><a href="" class="linkTabla">ver</a></td>
  
                </tr>
                <tr>
                  <td>PAPEL </td>
                  <td></td>
                  <td><a href="" class="linkTabla">ver</a></td>
  
                </tr>
                <tr>
                  <td>OTROS </td>
                  <td></td>
                  <td><a href="" class="linkTabla">ver</a></td>
  
                </tr>
              
            </tbody>
          </table> -->

          <div >
            <div class="card-group cards1">
              <div class="card cards2" >
                <img  src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMSEhMSExIWFRUWFxYVGBYYGBgWFxYZFxUXGBgVFxUYHyggGBolHhUXITEhJSk3Li4uGB83ODUtNygtLisBCgoKDg0OGxAQGzIlICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAMsA+AMBIgACEQEDEQH/xAAcAAEAAgIDAQAAAAAAAAAAAAAABAUGBwECAwj/xABJEAACAQIDAwgECgkCBgMBAAABAgADEQQhMQUSQQYTIlFhcYGRBzKhsRcjUlRykpOy0dIUQmJzgqLB0/AVNDNDU2PC4STi8Rb/xAAaAQACAwEBAAAAAAAAAAAAAAAABAIDBQEG/8QANBEAAgECBAMGBAYDAQEAAAAAAAECAxEEEiFRMUHwBRNxkaGxMmGB0RQiM1LB4SOy8dJD/9oADAMBAAIRAxEAPwDeMREAEREAEREAEREAEREAEREAEROrOBqbQA7REQAREQA8MViUpI1R2CqoJLHIACa1qek9v0no0gcNe1rHnSPlg3sPo28erIPSTsevicOvMknm2LtSH/MFsrdZXUDj32mmZpYLDU6kXKWvK2whiq84SSjpzvufRmAxqVqa1abBkYXBH+ZHskuau9GYqpWCU6u/RakK1ZbWFJ2JCKDf1iBc9ncJtGJVqapzyp365jdKbnG7QiIlRYIiIAIiIAIiIAIiIAIiIAIiIAIiIAJxK7beMejS30UHMA30F+NhrnbzmG4zaVWr67kj5IyXyGvjE8RjYUXlau+uZCdRRM8TFIbkOpC5E3FgeomeqVAwuCCOsZjzmu8BiubYNuhgM906HI+3jfsl5sTbG9XKlVUVBkBe28OPeRl4CVUe0IzaUlZt25/8IxqpmVxPB8QgYIWAY5gE2J7hPeaCdy0i4t3A6CbxJtqFA7Sdbd0wjbFGotUo7F2ytmW14C+fZM9q094EXIuLXGRHceEhNs1FUmmoDhWCtxuw1JOpuBmYni8M6ytfrw5/XgQnDMVeBpGmtIbzc+WF13iegWz3l0A3fbLl8SSStNd4jU3sqnqJ4nsHskLCFSBSpgo2tS4sy9dzxY8D3mWtKmFAAFgNBJ0I2jaL0068d2djwPHmqh1qW+ioH3t6cGjUGlS/0lU/d3ZLiX5F039yRCXEkELUG6TkDe6k9QPA9h9sxHlbyAXEua1BlpVGzcEHcc/Ky9U9ZAz75m9SmGBBFwciDxkfDMVJpsb2F1J1K9R7Rp4iTp1Z0pXT62fIhOnGayyMW5PcmeYwr4ffVq7MtV7aKSLBQbXIABzPE8LzMaV7C+thfvldhsVSOIdQtntYt8q2o8P6S1llWUpP83j5kKMYrWPhp8hERKy4REQARIGO2tSosFdrE55Amw6zbSTEYEAjQ5yKnFtpPVcQO8REkAiIgAiIgAiIgAiJXbU2gtIWLAMbW45bwBa3GwJMjOairsG7ErF4cVEZDowI/wDc15XwrI2443T25cbX7spe0+ULCtu796W8BvMovbieiB7pe06IqsKjrp6gI0Hyj2n2d8zasaeM+B6rT6dcNyqSVThyMaw3J12sb5fVB7ATn47st9k7JfD7xsjk8SxBA6h0TL6IzSwVKm048SUaaWphnKLB1WqNUZbLYAZ3GXbprfW2steS2JZqZBvZeLdZJNgeItaXpExflNgnVAyM3NjIpfJb6EDq4W4SmdF0Jyrxu91/P058SLjlbki3xW26FPWoCepekfZK2vyrUepTY95C+68xOcxGfaVaXw2Xr7/YrdWXIzzYtc1UNYixc6a2C5AX77nxlnKbkrUBw6j5JYHzv/US5mzh5ZqUXuk/MYi7pHi9ZV1YDInMgZCwJ7sx5ieoMhY7AioVJYiwK5WzVipIz09QZzxwGylpNvBmORXO2h3cshew3ch2k5ky/QLu5aSJi8ijdTgeDdG3tB8JLlbtvFCnT3jn0ky4mzBvcDKqrSi2+WvkD4HtTwFNXNQL0jfieOthJkiYHH06wujX6xoR3iS5Yp5ldO4RSS0EREDonBkeriQN+wLMoDFQLmxva3X6p8pCxqVam6orCmH0sh3jlci5PRylc6llor+XhztzBlDyiq0Xres1xk5UAjLquRnMrwLKaaFDdd0bvcBaYDtHDClVemCSFNrnU5A/1mX8mlK0t08Dl3Mqv/5TNwdWTrzul87blMJfmZcRETWLhERADTvw5D5gftx/bj4ch8wP24/tzTUR7uIbCXfTNy/DkPmB+3H9uPhyHzA/bj+3NNRDuIbB30zcvw5D5gftx/blmu3jj0p4k0+aDLkm9v2AZrHesNddJoiX+y+WGJoKqAq6KAArLoBkACtj5xHtDBSrUstLje+rfXEHUclZm4diPvYulR3Lh1di3BQhS4OWZO9bz6psUTTXop5U1MVj2puFVeaZkVRxBW92OvGbU2lgDVKm4FgwzFyN4r0lN8mG7ke2LYXDyoxyT0fPnyuvRl9L4bosbzgG8o6WxnG7esx3QFyLDK9LeAs2QPNkW/aM4o7HqqLLXt15NY9Egm29YHMEW6s7xvKtyeZ7F/PKtSDqVIuCCD3GU77Iqkg88bgKL9LMqzHf9bWzEW0FzlpaywOHNNN1mLdpJJ7rkkmRaViSbejRg9HZdVmZVQtukqToMjY5nLhLWhyVc+vUVewAsf6TJNn+oT1vUPgajWnVsfSBINRQRkQSLjvzmbS7OpWvK76+RUqcFqyFgcCMLoxZGNmvbong2XDgfCXMhNj6JGdRCPpL+MjUMSFO7Tdao4IGXeH0TfpDsOnXHYw7tWitProTTitEy2iRBjk/WJX6QK+05HwnJxycDvfRBb3SXeR3JXJJmGcqNoCo4RTdUvc9baHy085ktSm9TJugh1APTPeRko7s+0TGtq8nWp3and06v1h5ajuiWO72VO0Fdc9/LYrq3cdCno1WRgyMVYcR/mkkbc9IVXCoHOD55QOk61dzdPWU3DYdt/KQ5M2fsp65IVRu6MW9XuPX3TMwdepTmlBZr8t/t4+ZRGUk7RKH4ch8wP24/tx8OQ+YH7cf25keC9E+zlJZ6bVCTexZgg7FUHTvkjGei3ZjiwoFD1o7Kffaenz0/wBr8/7LbVTGKPpcDg1v0Td3mWgQa4ULkzhy/N5atw/VnjS9MA3OdODNqTKgHPZtzitmWKagUz373ZIfKj0VVcPRqfozGupem+61ldQoqBs9CPjB5TAMbhWo4YI+7vNW3rK6PktO1zuE2zc+RkYqlJ5b63VlwdtHw57X4LcrlOadmbZobcGMVcTuc3z17Jvb1t26+tYX/wCGTpxkJvTEuHZqP6CW5tihbngN4p0N63N5X3dJR8mcci4bAguovWdTcgW+LrnPq4eYmB7YYHEVyDcGrUIIzBBdswYpgKC/E1brS7/3kvYgptO6Ns/DkPmB+3H9uPhyHzA/bj+3NNRNfuIbHe+mbl+HIfMD9uP7cTTUQ7iGwd9MRES0qEREAEREALnkjtk4LGUcRwRhvjrRsmHkb+E+psJiVqotRCGVgGBGhB0nyxyV2T+k4hUPqL03+iD6vibDxM3nsTa5w/Rtemf1fk9q/hMjH4unSrxi+a1e23W1hilPLxM8iQsFtGlVF0cHs0I8DnJl5NSTV0xq5zI2Nq7q2HrN0VHaePcNT2AzipjF0Xpt1LnbvOi+M4oUTffexbQAaKOodfaeNvCQcr6LrrkDPahSCqqjQADymusY16lQ9bN94zZU1pyo21hsHiDR/RmqHdViwrFc2ubW3T/hjmFTzZYr25eLQhj6bnFapW3v9mecsuTbWxNPt3h/KZjf/wDZ4b5i325/JL3kbt7D4nEhBhzRYKXUmqX3iLAqBYZ2YnwjVWE1BuUXa3y+4jRof5I2kuK33v8AtNhiczgGczNuboiIgBje2Nhq7oU6JdrMBoRa5YdRt55S9w2HWmoRRYDL/O2dBnWP7KC38bG/3BPLG7RWkyqwN2DNlu6Ju31IJ9YaX4yilQgpSlFavp+tyOi1J8StfatPcDgkgkAWBvnbOxGQswNzlYjrg7Yo7m+HBGel87btwPrL530jFnsGZbliZoz008kVoOuNorZKh3aqjQOdH7L++bjo7Ups+5fMkAZGzHpZA8fVOenVKn0j4MVdm4tSNKZcdhTpA+yGZ02pdW5+hGaUos+XpzOZxNO4kIiJw4IiIAJJw2DeoCV3css3RPY7C8jTmcd+XXqjpZ4fk/ial9ymHta+7UpNa+l7N2GMRyfxNO2/TCXvbeqUlva17XbPUecl8jtrPQrbqIX53dTdB3elvdFrgZ2ucu2duWe1nr1txkKcyXTdJLXO9m2YyuFXLsiubFd9ktHJ+7W/lm3+526Kv/Sqv/b+2o/nj/Sqv7H21H88hTvSplmCjViFHeTYRm0915P/ANHDZ3IHZRo0C7Ab9U3yIborkoupIPE+MyedMDg9xERFJVFCiwJyUW4d09N03tY36uM8NiKzrVJVXzf/AD0sSMi5KbNDBqrqCPVUEXHabezzmRjAUv8App9URgcOKdNEH6oA8eJ85JnoMPh406ajbx8eY7GNlY6IgAsAAOoZTvERgkQdq7QTD0qlaobKiknrPUB2k2A75oHa20HxFapXf1nbet1DQKOwAAeE2L6YcYwTD0Qei7O7du4FCju6ZPgJrCbHZ9JRh3j4v2X9mZjKjcsnJe5xANiCMiMweInM4mgJl9szlljaFgtdmUfq1PjB5t0h4GZbsz0pjIYjD2/apm/8jafWnnya2Xs/adKzUhSxCDp80dy/AVFTNbHjlkfCQeUfo5qUKb1aNUVUQFirDdcKMyQRk1hnwmdJ4acslSOV+Xqh2PfxWaLuvP0ZsPY/KfC4rKjWUt8g3V+3otYnwl3Pmmm5UhlJBBBBBsQRoQeufQuwcWa2GoVW9Z6SOe9lBPtimLwqo2aejGMNiHUumj20rfSW3ihJ/wDP2T1q0Fb1gDkVz6ja47jujynTF0iw6OTKd5T2jgewgkeM5w9cOL6EZEHVT1H/ADOIRdnYZOhwFOwG4tgQQLaEAAHyUDwEHA0yAu4tgSQLZC6lTbqyYjuMlxJhZENdnUgwcIu8CSDbMXmP+k7HihszFEnNk5te0ud0e+ZS7AC5NgOM+f8A0u8shjKww9Fr0aJN2Gj1NCR2DSdjDvJKPVuvUhUkox8TXcRE02JCIicOCIiACIgmdOnehWZGDqxVlIIINiCNCDOa9ZnYu7FmY3JJuSTxJmebJ5H0UqItValU7gqE2C0BfRb6u2WnVrI3pB2JSopSq0kVBcoyqLA3BYN35EeUz4dp0Z1o0o3158ve/odMc5ObBrY6utCitycyx9VF4s0+g+SXo+wmBUHmxVrcargE3/ZGiiQfQ/ydXDYJapX43EDnGPEL+ovln4zPbzlWfeP5dav+FwSGqVNJXYE8q1BXFmUEduc9bxeQevEuIJLU87lk4g5sg6wdWHYc/dJiMCARoZ2kTCjcZqfD1l7ATmvgfYRK/hfyAmRESwDVvplPxmF+jV99Oa7mwvTIfjcL9Cp95PwmvZv4P9CP1/2Zj4n9WX09kIiIyUHvs3H1MPVWtSbddTcH3gjiDxEzDlL6QDisNzCUzTZ8qpuCLfJQjOx43GmWd5hE4lU6MJyUpLVda7k41JRTSfE4m/8Akf8A7HCfuKX3BNATf/I//Y4T9xS+4Il2l8EfFjWB+J+C9y5kavhgTvAlW+UPcRoR3yTEyGk+JpFfiMS9JGZ1DKouSpsfqn8ZVVOViW6NJie0ge68utqLejVH7DfdM11MvHYirRklB8V4lNSbjaxF9Ie2K9bB1rOUACmyEjLfG8CdTlcTSc3HymW+ExH7p/Yt5puaPY1SVSlJyd3m/hC0m27sRETXICIiACIiACG0nMk4XA1KgJRCwGR0/qYZlHVs6bpwp6CfRX3CYv6SRfDJ++X7jyjo7X2mqqgGSgAEqhNhpc8ZD2tVx+JULVBZQbgAIova18tdTPNYTs+VLERqSnCyd/i/o63c+mdmUwtGko0CKB3BRIm0MFVcvuMFvuFWJJKst/1bW4jjwkXkRtHn8FQZsnCBHHEMosR7j4yTV2QGdnNRukQbXNhYjLW1siNNDxmjTdkOvWJ5foWJtlWF+03tYJa1lF8w2ozB8mEwVZCWaqLFt989bIikm447hy/VvxtOq7EfK9ZhYqbjUhQouxJ1y4dZ1vOauwiRbnTbc3LAZHMZsL9I8e8k9ktut/QjZ7epYbLVxTHONvMc75acNMr2te2V7zvUHxqfRce1J54DBc1vdMtc8eGZPnna/UB1Tsh3qpPBF3f4msSPABfOU1Hd6bk1wRMiIkiRqr0x/wDGw30H+8Jr6bD9Mg+Nwv0Kn3k/Ga8m/g/0I/X3Zj4n9WXXJCIiMlAiIgB1m/8Akf8A7HCfuKX3BNATf/I//Y4T9xS+4JndpfBHxY7gfifgvcuDKSrykpKzIyuCpIOQOnjLyYjyvwVmWqBk3RbvGh8vdPPYypUp089Plx8B+o2ldE7F8oKD06ihjcqwAKnUgjXSYfOYmFiMROu05ctheUnLiVnKS/6JiLAkmk4AGZNxbSacdCuoI7xb3ze08MdiEp02qVDZFBJJ/wAzPC3bHOz+0HhYuChmu97Pa3BlbNHRJ22donEVWqkBQclUWAVRoMtT1nrJkKeti20sys/P1InETmJ0DiJzEAPpr4ONl/Mk+s/5oPo32X8yTzf80yyJnZ5bmhlWxiXwbbK+ZU/N/wA0fBrsr5lT83/NMtiGeW7CyKLZmwaOCU/olIIpN3pgsQ2VrjeJswt4+0W9Csri6m493YRwPZPaRauEUneF1b5Smx8eDeMrd73QWtwJUTH9s7Sq4crbddWvmQQbjgbG3s65S4nlFXcWBCfRFj5kmKVcdSptxle6+X88CEqkVoZfXxGe4gu54cF/abqHZqZ6YaiEUDXiSdSTmSZjHJTaFnakx9c7wJ+VbMX7QPZMuluHqqtHvF4eBKEsyuIiIwSNWemQfGYX6NX305rybL9MWFYjDVQOipqIT1Ft0r57reU1nN7BP/BH6+7f8mPil/lfXJHMREaKBERADrN/8j/9jhP3FL7gmgDPoTk5hmpYXD02yZKVNSOohBcTN7T+GPix3A/FLwRaSJtLCCrTZDxGXYRmD5yXEyHFSTTNI1g6kEgixBsR1EZGJecq8DuVRUAyfXvGvmM/OUc8vWpOnNwfLpegk42djiZBgOSdGvR/+VS5wMQwQlgABoTukXOd8+yR+Tmy+dffYdBD9Y8B3dcze00ezcN/9pfT7l1KF9WYp8HGy/mafWqfmnPwcbL+Zp9ap+aZXE2s8ty7KtjFPg42X8zT61T80fBxsv5mn1qn5plcQzy3DKtjFPg42X8zT61T80TK4hnluGVbCIiROiIiACInnVqqouxAHWcoARNr4IVqTJx1U9TDT8PGa/ZSCQRYjIjqImbDlBRJ1YDW9srbt7/075Wcp9m3+Pp6H1x7m/oZkY6nGrHvKbu1xtt/XsUVFm/MjHUYggg2INweq0zTZe1WrIN1CXGTE5ID137eof8AuYns7CGtUWmOOp6gNTNgYbDrTUKosBpIdmwm25J2j7v5HKKfHkeYwzH1qjdy9Efj7Zx+idTuP4ifY1xJcTXyIYsVO0MJv02p1kFakws2Vm77DUjW62ItkJidX0Y4d+lSr1FU5gEK48DkfObCkE/FuCPVc2I6mOjeOh7bdssp1qlH4JOxXOlCfxK5g/wV0/nT/UX8Y+Cqn86f6i/jNjRGPxlf93sQ/DUv2mufgqp/On+ov4yL8G1Mm1OuzWyLbihB/FfPwBmw63xjGmPVHrnrvogPdmewjrkpFAAAFgOHVIfjcRJ6SsvBfawfhqX7TCtiejylQdarVOcdTdd5RuqRod0HM98y086Pkv2WKHzuRJcSmo5VHeUnfx6XoWQpxgrRViNQxAbKxVhqpyPf1EdoymN7Y26edUUz0abXP7Z0I7rXHj3TI8dhFqqVNwbEBhkRfLIzX+LwxpOyNqpt39REzO0KtWnFKPB8/ZEasmloZxtPDjEUCFzuAyHttcfh4zCcFhGq1BTUZnX9kDUmZNySxu8hpHVMx9E/gfeJbYTApTZ3UZubn8B2XufGE8PHF5KvDfrx0OOKqWZ6YTDrTRUUWAH+E9skRE0kklZFwiInQEREAEREAEREAEREAEx3lW5si3spJvmc7dY0sMje8yKQtoYVaqFWNhqDfQ2sDrna8pxFN1KTiuZGSumiiq4Gh+jBwenYG+9q3FbX7xJnJc3pMp9W5FujbPMiwz48ZBXYSlrCqurC363RK5EaaE36spHolglR1rc3zZstPjbtzz6uOkz4t06im4W0a0a1sr79citOzvYutlbMWjXqldCqWHyQxa4/lEs2rqGCllDHRbi57hqdJC2bWLlWbV6anvKlgT/MvnO+N2YlVt5rnIC3DIk3tocmIz4EzRw8YKNo6L76lnBflJr1ALXNrkDxOgne8pG5PIdXbj8niBmMsmyzbU8Z6LsVb3LEneLEkKbkljbT1ekTbgQDrL7R39AvLb1LSnVB0IPcb6i49k8scl6bjjYkdhGYPmBK2jsBFIO+xtukXtqrbwOmvC/VYcJY4+ruUqjHgpPskKiVn4ME3bU96T3APWAfOdjMUw/KqwANLQAZN1dlp6PyrBBHNH6w/CJrH0LXzej+xHvY7l7s/wBQMdX6Z/iz9gIHhJUpauz1xNGjdiAF4cQyhWB7Cu8vjH+ivvFv0h737RYZdEZ5DL3eLkFHKtfQ7d8kXV5xvjrlP/o78MRUGXWTc2XpE3z9X29WU5qbEB3itRlZixJBI1qb4yBtl0h/EZKy3O3excXmL8rsIWekyi7NdbDU2zHvMsH2O/6uIqAdLK7H1t62Za+QI+qJ746pubp1KU6jX7gBf2xfFUo1KTi3t9NSMvzKzPLYWyhRW5sah9Y9X7IlvMT5NbTCXSpcc4xZWOhJyIv3jWZZI4SdOVJZFZbbeJ2DTWgiIjJMREQAREQAREQAREQAREQATFuUmMJfmlOQFmAN73F91lt2XGfleZTMZ5R4FywqLdhkCNbG4ACqBfic78Ypjc/dPL0iFS+XQh43Yb06e+SD8oDUXy9awvr/APsmbFwdKuCzpdgczcANfMdBdBa2usg4jatWqgpm3C9lIJzsLk5Wvbqz8p3rUnoolO+4ahO9oCBpulgc1zOvXEIulGeaEbxS1uufL63KllvotDJcTSyUoM0zA6xaxXxHtAntSrBgGByP+WI4GY2ab4WtTAqFw+oz4t1X7Sb9pl8+GIJZDusdQc1bvHA9o9s0aVRyb0s1o19PsXRlcmRIgxLD1qbDtXpjwtn7IGNB0Vz/AAMvtYAS7PE7clXmLcqtpA/Eqb53c92i/wBfKXpFR9fi16gbuey4yXwv3iQK/Jmi2Y3l7jf714vilVqU8tPnu7aeRGak1ZGFxMqbkkOFU+K3/qJ1HJH/AL38n/2mO+z8R+31RR3cj05J48FTRJzXNe0E5jwPvmSTHcPyXVSG517jMEWWx9stVqumTgsPlqL/AFkGYPdcd02ML3kKajUXDn8vmXwulZk2JGXG0z/zF+sL+U4bGpwbePUvSP8ALpGc8dyZIZrC5lViF5ynVc3AcBVyJO5fXd6yST3WkkU2qeuN1fkak/SIyt2Dx6pLq6SDWdPY5xKjaeDprhxTK7wUWB4ggE73j/WRdg4+ovN06gJVwebf6N7o3da34yy2qL82nynA6sgQT7AZSotJR8YWBuClnYBd9CSbAi3SVs+0RSqslVSjpZJbLS3H6aLbT5kHozLInlRqBlDKbgjI63nrH07lgiInQEREAEREAEREAEREAEREAPJaKjRQOGnC97ecjbS2etZbHIjQ8Qf8tJ0SMoqSaa0B68SlwGwVpvvlixGlwMszb2W8pdRE5Tpxpq0VY4klwE4nWLyVzp3idLxeGYCHU2kgqGn094botuNYlw5AV7brECmxIByAz1EhLynwxVXDkq191grEEqCSL2ysBfPhfqMta1BX6LqrL1MAR5GR/wDTqP8A0afSGfQXPvynMwHliNuUUbcYtfPRWIyTfOYFvVzkjZ+Np1k5ym28u863zAJRyhtfUXU2OhGYyM6HBUszzSXJzO4tzvdFs7cVAHhJVOmFGQA1OQ4kkk+JnbgdygOonInF5yIKwHM6sLztE6BX4zCM9RGBWyg2BF8yLX7rSjfkrUJuaqnvB8plkRarhKdXWa9etiEoKXErdjYJ6KbjMGAJK24A8M+2WURL4QUIqK4IklZWEREkdEREAEREAP/Z" class="card-img-top IMGP4" alt="...">
                <div class="card-body">
                  <h5 class="card-title tituloh2 text1">Ciclo de vida de los envases</h5><br>
                  <a href="https://aniq.org.mx/eventos/2016/Foro%20Cipres/docs/6%20An%C3%A1lisis%20de%20Ciclo%20de%20Vida%20PEAD%20-%20%20CADIS.pdf" class="btn btn-primary boton1">ver</a>
                </div>
              </div>
              <div class="card cards2" >
                <img src="https://papelsa.com/wp-content/themes/papelsa/assets/images/grafico3-sostenibilidad.jpg" class="card-img-top IMGP4" alt="...">
                <div class="card-body">
                  <h5 class="card-title tituloh2 text1">Ciclo de vida de papel y cartón</h5> <br>
                  <a href="https://papelsa.com/sostenibilidad/" class="btn btn-primary boton1">ver</a>
                </div>
              </div>
              <div class="card cards2" >
                <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBQSEhcUExQXGBcZHBkZGhkZGRkeIx4dGRgaHiAdIB4aIC0jICIpHhgZJTYkKS0vMzMzGiM4PjgyPSwyMy8BCwsLDw4PHhISHjIqIyoyMjIyMjI0MjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMjIyMv/AABEIAOMA3gMBIgACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAABQYBAwQHAv/EAD8QAAIBAgQDBgQDBQcEAwAAAAECEQADBBIhMQVBUQYTImFxgTKRobFCUsEUI3Lh8AdigpKy0fEVM6LCNEPS/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAIDBAEF/8QAJBEAAgMAAgICAwADAAAAAAAAAAECAxEhMRJBBDITIlEUYXH/2gAMAwEAAhEDEQA/APZqUpQApSlAClKUAKUr4dgASTAGpNAHxduqilmYKo1JYgADzJ2rYrA7V5b2346cUTh7Rm2R4o9J1PIQQSeQIA1bSK7PdqL3CVFu4rXMJJPM3FlYAtgsFySAY/iPOrr483HUZ/8AIh5+J7RSojh/GUvYVMSoEOJVQ4bUmAuYadPT2rhF2417Nnb4W0BOXRlA8OxHxDXpNSUWykppFlpXFh8YGIVtGO3Q+n+33rtpWsHTT5RmlfDOBuQPWvqg6ZpSlAClKUAYr4uXAoliAOpMV91Rv7V7M4JLmYqLd+0xggSHm2ZJ5eOdjttzHYrWkck8Wlju8fwq3EttfQM7BFE7s2w6SeXWpWvEOMoLeHt4i2mtl0cZkMSjBh8bAnbkBvXs2BxIu2kuAEB1DAHLMESPhJGo10J3qt1Xg0Qou/Km8OulKVE0ClKUAKUpQBVuJdtsJYuvZJdriHKyqp0MA7tAOhG01HcB7ejF44YX9nKKUdlfPJzLBgrlGUZZ1mq12xsWxxZ41Lpbci2jXCXXwsGVTAOXIYPIg86icZimwmOwl1UuKRcTS64tgrclD4FBZV11JB225VsVEHX5LvDD+exX+D6PdaVqtzAzAAwJAMiecGBPrArbWM3CuPieCXEWLlliVW4jWyVMEB1Kkg9da7KUAeC8T4ViOEXh+0DvrNwmbihgGAMw86KSzSRJJjfp12blvGMLdsB7t3lsqDcLp+EaFjtsonn63xnhFvGWjZvAm2SpIBGuUzBkbf7AiCKofZfskMJj8Wqt+5UoqTJcrcUOBm/KuqzqTB21nZX8h+OPsxXfGi35I1cO7P4XAWrlyTcy6CWIDXdczqJgakIAPytvEiwcDxGZQ1w/vWUeBQfCoJIA9yZnpXHxfhiu8j4bRNxhtmnWdBq2YakzziNZ1W7TBFOYgmWYr5wRqOmgpeGhNe8lkxBhTPh5z0jb5GuLEcdd0YocoQANEAszGAQeQ2OnmJ0qJxLYi60eJt4IWR5bDSvjBcPFxitxzADAhT8bBSYOXQBRJg6/WuOK9jKb6RI8KQOS9zxP+EMZMfmg+q/0a78Pfe24CHwzBQkxqJ0/L7dOdcmMQjum2YrMjecqDT6192MWLjASA6/EAd42Yc4M+0x0JVrQUmmWFOIJEv4I3LbeubYD1iu0GqdxG4bisq/DIUebFgs+gmKnuD38wZD+BiAeqnUD/D8PtU5Rw0Qs8njJWlKUhYxVc7a2Bewr4fKrPdBRM34Z0Z5gxlB08yBzqx1AYvxYl55BAP4Yn/UT9KaK1k7JeMSv4Ts0O7FsyREa3G+yhQfcmpnh1tsEqosm0BGQ65QPydAB+HaF0jn0ha6SS6wYkaiqSk5dmeC8eiRtsGAIMg6g+RrZUZwlzDIY8JkR0af/AGDexFSVRZri9WmaUpQdMUpXJjrhCwJltNOQ5n5aT5ihHG8WlW7Udn/+oYlGGIuWlsq1s93ILl8rMM06AQvI6z0rSewGDchrtt7rDY3HIH+W1lB9wasAcJAGn9bfzrcmJJ2NWTaWGZvZacmGuNhhlGZ0GmUksyj+6Tqw/uknyPKpu3cDKGUggiQRzBqDbE5wGAk9AOf9aV0cHLKWQwAfEqzMa+ITtuQYHU60ko+ykJ84yZpSlIWMVB4q5lbEOAJQfPLaDD6vU5UDxLD5rrW/w3VBPnl8Le0ZBHUjlNNHsnZ9Tjwdo3GDtPd6ZR+eNcxncTt136T1X8IjNLTB1ygkAmdSQNK72t6AiuS+STlUSx0A+8+WtU0zePohbuFe9dyyTaPw21OQARuYG3Mz1rtvcIXDIMg8IkSBzcFTPud6nOH4EWgSTmZvib9B5V03LYdSrCQRBB5g0rnzwWjUs57Kzj7LHJl5eH/x/l9qhcdbAdXDhXBgESxBgx8Ib5Herlj8GgtsVUSIbXxbb7zymofHWxCueRlR00Ovr9qeM9IWQ8WQd/EXXU2UGS6r28z8gN8wG4KgEwdZPnVj7OKwOoYQuUBjJIDkZyRpLxmjlJk8hSsBgb95GyXWs3O9du8yhpzEnUSJkENqCPKr32Zs3FRjeuC5cnJmChQQskQBzlyD5jlTWpKIUftLSepSlZjcYqF4lam5I0OUEHzkgj0IA+nSpqo7ia+JG/iX5wf/AFpo9k7FsTlsXMwkeen3r6D6+lalXK4Yc9G8/OtzrrT4ZzZhvDcX+8pH6/SDUpUL32WD0Mg++o+496mQaSRet8YfVKUpSpiuXGL8LdD9Dof0rqrVfTMpHy9RqPrXUcktRquKsQQCOhrmfCruAB618viuYEnz/r6VzM5Yy2tUSMzaOfhtkrbYMyEh7uzA6d40e8aR5V14V4upB3lfYqT91HyrjKFLbnzuH/O7Ef6q7uC2883Tt8Ken4j8xHsetEuggtkiapSlSNQr4dAdwD6190oA5f2ROQK/wkj6AxX3asKmw9SdT8zW6lGnMRmlKUHT5YSKrPE0yxbYnoNtVOk6jeDB/mKs9ar1hHEOqsOjAH700XhOyHkjz7BcPuXHyACQ4JkSB4EBkHQLA9depq/4ayLaBV2H1nUn1JJPvX1YsIghFVR0UAfattdlPyOV1qBmlYrNIVMVxcUSUnmpB/T9a7a130zKy9QR8xXUcktWEKGkgNodweR/nE6V0qkg+VfChWGo39axbuEHUyT9Y/WP1qpkNd5Mp30bT3if0PnUlw67mtITvEH1U5T9RUfiX8BMbFT/AJWE/Sa6uCNNlfVif8RLf+1JLorU+SSpSlIXFKUoAh+JYQgl0JE/F09dvnXBcW4seLU6CI3Htt/tVlNVO7if3kj4ASEnpMN8pHsPWqQe8GeyKXJsxFv90FLaHKC2mxYT5Dep/h4AtIAIAAAHkun6VDXrQNspB+Ej+vepHgd0tYUMCGUBWnqADJ84InzmifR2vsk6UpUy5ilK5cTiI8K7/b+dBxvBiMYqEAySeQ3/ANhUVxbtTh8Kha6WQwcoKOcxjQSgbcwPetroPB8U5ukzKtvXJxjAC8mQqSVOYDQHbYTpmgypOgZUPKn8USdjPOOLdqcdxKyPCcPZIVotswa4ROYZ5EKCQYjlM6VcewnGxCYV7mZoOTfZfwyecA6DTT1Ap3aG4+GJSzbNwXM122lpSSjqTmOSCe7JbNpBRpU1bOxHYb9ndcXiXL3zLKiZltpmBHwkAs2U8wAOQ0Bq0/BQxE6/ySnr6PQaUpWY1Gu4YU+h+1eP3cVbuW5z5idyXkzXqXGeILhrLXCMx2VJALMdlEkD+QNULB8OuC3+8ZjJLFYZRJMzltqYGvP5mr0tLWzJ8nXiR0f2Wu+fFqXYoO5yqXnKT3mYgTpIyfIV6NVA7JY84fFPh3tsqXSGt3DBBcCCkwCJUAiecjnV/qdj2TaLU/RIzWKzSkKkQB4nXXwsRt1AYR10YD1BrDKGaAdQB71t4gQrrofHKeUgFtfUZvkK50UAyB9N9P8AbSqxeoyzWPDF1CVZdiQR7kVs4G/hCn8qn3AAP6V9ggnfYf8AB8/5VyYW7kvBDzMg9VaRA9GI+VD5QQeSRYKUpUjUKUpQB8ttVWxyDKy7FgrD+Jl5e4PzNSnEOJhWKKJbmdIX584qPRQYeZYqonoIGg6VSCM9sk+EfeIvEqY/4613cDbMrtEAsB8gJqLVDrmOvz02mp7hdsLZtgflB921P1Jom+AqXOnZSlarjhQSdh0E/QVM0HziLmUabnQev9a+1Rl64qaswA/vEDc+dLneXDmMIuoA+JgPONAT5H7VzPZtkkTmY7+KY8yAdaeKM9ktZjF4tcoy3VGs6HcZWG+3pX1w64hRAHVmC65TPKCxnz+9cGIwiNbAy6ztqDynY9J1862cJ4MtxVYF1VWfUMQWILDSDoJ5zrHQ0zxImtbxHdw7CqcS9wLqEyltdS5BOm0xbGsTqKnq02LCoIUeZ6knmTW6pt6zVGPisM0pSuDFMxhGI4rkdh3dhBlQtE3HAbNH4vCwHllqYv2lA5fSoTF2C/GCEbKRZBYkAzDLoAR0K6+tTeKsNpL8+i/7VRIyz5bIPtJwtbiI+YrkuJBQ6+JgmhH8UjoVB5VauFYg3bFt2EFlBPrz+tVDtDw9yinvBHeW9Cg3zCNQeRg+1WvgMfsljLt3duP8ork+hqXyyRpSlIaDkx1sshgSw8S+q6ge+3vUbYcMoIJPn/X6VOVTuK8SXBO63mCWiGe2x3MkEhQdDlk+EawAdjTwfojbH2S//HLp5Vox9g3F8EC4viQnbN0PkaoHEO2WIxLhOH27jrDElFzO2k5ZylUgDYSTI1nSrD2cwnFrlsNiLipIiHt2ww138I105GNefMUaxa2SSb9F14fie9trcgrmElTuDsR7EEe1dVc2Cw4tW1QEmOZ5kmSfck101A1LoVxcQxfdrpqx+EfqfKu2qvx7GGzcLNavXAYyFEzDYSDqI11jnOlNFaxZtpcGhMNprJJksSRqTqfmZrrUQIAiqxi+2GVsqYO/63FKz/CEV535xXfw3tJhr4GS6oc//WzANMxp116VdxeaZdWkniG8JPQH7VZbCwqjoAPpVXuyxCDVn0A6yN/Tzq1qIFRmXq9ma5uIf9s+q/6hXTXJxJwtpidBpP8AmFIir6OG4gGuUSdBIHM9elAPU+f/ABXzxBwtxQSBIJifyiNB/j19qzexGW2Sq6yqCersqz6DNPtVDKyOxMse7tyMxzM2wVcsHUfiM7dJ5xVg4dbCWkCiBGg8jqPpUbZtqikAyx0k7/1J35mpwCBpXJv0UqXbPqlKUhcUpSgCmYkr/wBXOcFosDKFBMS/PKNNQ2p6jqKmcTk6H5H9ahscr2eLI4Af9otsqCcpXuwpYHkRAmfOOVTWIZ+af+X8qojLPtkJx+3bNsHu2Pjt8jtnE/SasnBP/i2dv+2m0flHTSqx2juXMiqE1a4kHPHwN3h+iEe9Wfg2Gazh7dt2DMiKrECASBy8qJ9DU9skKUpUzQK13LSsIZQw6EA/etlKAPlVA0AivqlKAFKUoAV8kToa+qUAcf7Db1hAJ18OmvWBz865sTwHD3AQ9sNPM77zvvUpSu6xXFP0cGC4XbsmUBmIlmZjHSWNd9KzXDqSXRiuDiYVkyNs0yPIb/Uj5131E4y4M7EnQCPQDUn+uldXYs3iOXGXQbiMV1VWXN0zFD9co26VzXLhBUmcoIJOvmAfmR6an03XELhjqJjKPJTInnJJ+1YsOHSdp+4Jn6iqIys2jM1y0FG7gtPJVUt85Cj51P1C8KGZ9fwqfYsRH0DVNCkl2aKl+pmlKUpUUpSgCkYhlu8TupeIKoiC14Q2WVVmjMCoMnUkflqVu4VQIFx29Rb/AESomwGPFcXkQMIt55Ex+7twQJA1gb/k0nlPYjNA8IA6afptVUZJdshePYe2LZYhSQU/CCR41BgRMwTVi4JiO8w9ti2YkQT1IJB256VA9oS3cmACcyRO094sT5T96mOy8/sluVynxaf42++/vXJ9DU9nTxPilnDIHv3FtqTlBYxJgmB1MAmPKqxxX+0PDWULoly4ACdBl0H8Wv0rP9qWDD8OZ4lrLpdXUCIOVt9/AzaDUmKoNpLVywVUZtJGUT9WMAR0q/x6I2Jtkvl/JnU44uGe2Ya+txFdTKsAynqGEj6Gt1U7+zLib4jAIHibRNonPmbwEwGAUAeApGpkGauNZZLG0bU9WmaUpXDopSlAClKUAfNUvDdvbLX79soQlp8guAyGjciQNmDCBO086mO1nFDhMI91QpPwqrOUln0UKVB8RYjpzMiJrzThmS3bVbouI4lmN1RcDMdWbMALikmTIrT8epT3TL8m/wDGlnZ6vg+L2buXK4lvhB0J9Ad9jt0qRryTsZgkxHFRcUSmHtl8yPmXO+ZVBnxAw1wwZ2r1upWwUJYitM3OCbMGq5YY3BmcrrByjYE66nn8hVkqDxHApJ7q/ctz+EZWA9MwkfPTYRSxaO2RcugwNcyeBmXr4gNNOoHuR86g8V2Ux1u4t2xinZg0nO5OYdCraEazHl1re2MxCsqvhbucH4lRmVtNSDrBM7MdOumlePTM7Ul2iy8ETS43VoHooj/UXqVrk4bYNu0it8QEtH5m1aPLMTXVUX2aorEkfVKxWa4MKxWaUAUQKDxXETq0W8ugYD92k5sxAEctz4tOdTuIZepJ9tPZarobNxjEIBKkWy0BCQy2rZHxg8mHw/8ANjxMgARA6afoIqpjfv8A6Q/aFlNlgSTMAqNSQWGnUTtqQPOpvsmQcHbykkePU/xtP1qA7Qs5twsEkqBInXMCNZEbcwQecCp/so04O0ZB0bUbHxtqKJ9D09mO0hRrDWmUOzq6ohjdlK5pPwgZtW3g6STBoXA+yT2rapcxGYxH7saQIkAyrbabkeXKrv2j4czxdtsQ4yqVzEBhm02I18R5jffSo+1eLr4JzDe2dWVo5zy13OhpqpOK4Yt68njRzcJ4ImBJbCBkJMuCxbP0LLsfYAxMEVbsFiu8WYhhEgGRrsQeYPI1BWLLq6hm8bhmfXTNpCwNoAIH8POa7+EIe9uHZVCrvPjMs3yBX/MaSa9jVSe4TVKUqZpFKUoAxXLisUE0AljsP1J5CuqoS3czsz9WIHoDA+31porRJyxHPjsCl+Gvr3hUym4yGN0gyD5zPnUfjeBo6wjsp5BxnBP94mHb0LRVhAmtbLVoycejNKCl9iv9gOBDCnEZwhum5mDouXwMigL6ZlfTUbGrtUJgvDiBH4lYH2gg/SpupWNuWs0V/VIzSlKQoKxWaUAKUpQBiq72o7U2OHhBcDPcuE5EWJIESxnQATufatvajtFawFhrlxvFlORACWYjoBy8zA21E14i/EL2NxT4y78ZjIs/BbHwhOWhJkdTqIY1aqrzfPRK2xQiz2zgfamxijlEq/5WjX0I0NT9eGXeJAqi2LTHEZh3ItkeJm0KtzgHxAjaDJgkn3C3MCd4E+tF1ag+Bfj2OyOsrGLwF6xjnxVq33iXUAdQyhg6CAQG3BUAaHrI2IieJdpMSr5bfDcRcAI8RW4skiSAO7Og2nafYn0ClIp52tGlVvs8zxvD8ZintuLd22wXW0yqERiCPj0zwYM+fLUVe+BYH9mw1qzpKKAY2ncx5STUjFK5KbksCFai9NGKtZ0KgwdCD5gyPqKrTZrd9WkeLwOIgwBIzHyMmek8qtlVvtbwxbiC5qMujsu+RtCf8Mz6TXYSx4ctjq1GjDMDcu3GP/b8IHMhRq3vrHqfKpfgdplRy3xM7MfUhdPbaqvw2+7GGgOjNbY/mUuYf1DBZn9auPDkyp6kn6x+lNPonT9jrrg4tijatlljMSFWerGBpz6xXfUD2lvR3S9XB0/ukf17VOK1l5vItnzwjizHE3MLdYM6qt1GC5ZQ6EEbSrc+YPlVgFeb4viQtcVR38K5bSkkGFzm4rTAncAa6eP5ekU1kfHBapeSFQtkb+rf6jU1UBh38K9T9tyaIBZ6O9Doa5sS4Cmdq+80DfzpgrHeMLh+AfAOp/N6dPn0p285JpbwjPDMGwc3XGpGVRzCmCZ9SBp5VK0pUm9NEViwzSsVmuHRSlKAMTXw4kGDB69K5MTxK2ik5gxAJyqQTp76epqmcV41dN+3nbureYBAASJIAlj/AIxGggrypowcicrIxK/2j4TeVmLku5YBy+7ZpMztBC+GNBEQsRUAuC7tWyhshY5IB8J/LvpJ/CdROkV6bxLiFu53Vlrid6r51IOYEBGEMw2mQNSCdKgsVhC1xy1s57h8DKBBAAzDwDlB0kHUDzrbTZ4rGjz76/J/qyK7CJkxr4q+hXL4LasQW8ZCFlA+KNieQJida9kFeO3+HXLfjtqpKtmbdiSD4TlZiQQRyOsDQRXoHZLiwvIUZpdQCAd8p/1AEEZhyioX/s/I1fHli8SyUpSs5qFKUoAVrdQwIIkHQg8wa2UoA894ng7uFvt3eqt8IMwywAVPRsqxpvExrUnwziRuaZnWAYUyIAI0Yjc6nXnGm9WPiOCW8hRh5g9DyqtJgsQjGCwIMg5WMCNRmXRpgaRrFWUlJcmWcHGXHRJPj2AlXI/iGnzYVA4vFvffvWIyIVtrH4nL6wPIT8xUnctNdXxXjJ0MqB/4bg+8+dbsPw9UAIlyohfCYWd8q6xPMkk6nWurFyK/J8EXxrhCYpCjL4wDlPMHqD+moPrBqx9n8S1zDpnEXFGRxM+JQBM8wRDDyYVyNh3MEI0jXaPbWKkOGYPukI3ZmLNMnUxO/oPXU86Sb1FKotM7W2qvYFv3ak75QD7bj51Y6quItOl11Csy5iywrai4SSA0RoQfnXIfwexeyUs2e9OvwDf+8enp1+VSwFV1cViNlRlAiAEMR5GPvWpeJ3c4BzJyMqWEx0P8q64tnIyjFFnrE1XHe4/xXW15Ke7/AEn61qt4dmYhzqNi2p15/wDEVz8YO3/RYnxSLu6j3FctzjNhd316AMfsNajG4fGrsW+g+mvzNQ3aXGW8JYZgAHaQunOD4iOYHQ7kqu5plWmcdrLxYvLcUOplWEg+VRXai4y4c5TGYqrax4SdieQJhSejGnZK0yYGwGOZigYkiJzktMcviqUxFoMpB0nmOR5H2MGp9Mq9cTzfhfFrGKc22tizcjwrcVTmRdGNttVJDT5kBTHTXi7lsW/+38NxgvevIORissjbSmuwAzDXSujtbwC2c7XEEjMylCVKswHiAG8lQQSDqsToK4OEYh82UkvftOLfe6xdt3UW4neZtTILDnBE8ya0rM1GKXeYZ4fgLLFv3SWwYM22uEEayNFYEzGwAE86ksSjYcJcAdlXqjqY2y5guXQExI5+QiZw+Ct30DhG8wBEEHVTAjf9K+l7OLyRxy+JQD5kDX5daVzR1Vv0iJxOOtPlLZ8r5pRVjNK/E0xAI1hTBM61YezuBI/elpVlGQdJ+In1hR7HrWhOzKgEKAkz4pzEEjeCOR13GtWO0gVQo0AAA9BpSTmmsRautp6zbSlKkaDFKhsfxV1drdtAWABljpJ5QN9158z0rmRL763buXSctuVieXWmUWTlYkTt68qCWYKJAkkDUmANepMVVOMdvcNYupZtBsRcZspFoghYbKQTzaQfCATUN2t4NfxNp7YvOVEOqMxIYrDAHNJ3Vhv+LbQVWHTD4dEu2DltuuZS2rbeNI/MpzAjTSeSmr10KXLZnt+S4/VHtWGvrcUMpkHWttUj+zPiVzEWHPdMlpWi25AAbrl1kgbTtoACYMXioSj4yaNUJOS1oUrNKUYUpSgBWKzSgDFcuJwiXPiGvIjQj3/Q11UoONaQd7DvbMkyv5h+o5favhj9NjU/FRmJ4ZztnKfyn4T/APn208qpGf8AScq/4aUuQNa847TYJsZxa3h0Dlcyrd1OQIFW4BIggkEnQg6mr67shi4jL5xK+xGnz1rV2b4XF+9i2zA3DlQNp4E0DQdRIgDyB/NVFPxTaJxhslpZbaBQABAAAA6AbCtlKVnNJxY3BJeUq4BkEAxtIj+hsaoWP4ELGJZ3lBdgOw+EgABTM+HKwGu8HWQK9JoRTRk0TlBSIfs5Yy2NY1ZzInxCYDGSdSADvrvpMVMUpSt6x0sWClV/tBjsgYZigQZp1gkDNBjkBBI5z5GuLg/GO+tLcRmkErcUtORl3kGQBzidiCJEGnUG1pOVqTwttVvtLj2BSzbnM2phiuUdZUgkgSco6CuLi3a82xltoGaD4mMKPPL8Te2mhqhtxS8l4Ot0PcuyjkmY6AD4lExzk+ZqldTb1kbb1mRO48VutdS5bd2QtvcLRl0GrGSIHPXf5zfCe01xz3ZAuPtm1HuARJWZ3M6b1o4B2dv3kLd4ottIEq558iSCYOgmRpNWS32YS2PAMpH4lb4tOYIjmdB0p5yh0ThCzNBTMhObM2sHl/DA+Ecuv2qs8D7Arfu/tOIuZk726xw5QG20DICQDAaQSSBrA0FWZOG4hDKqrjnqFkekkT5zU7w+x3dtU5gSfViSfqTUpTaWJlq4Py1o6QIr6pSpGkUpSgBSlKAFKUoAUpSgBSlKAFKUoAUpSgBSlKAFKUoArHFxmLhj4WbVfDsoAOp22B66ivPuGpcuLjEsrNoXwyshCqDkIKgDbTKZ2E+w9C7QYWGZypKOAHKgSAN80/hYKBPLWdKr/Z6w5RmQC41x+8dVELnyqg1/CoVBIO7TGmlaYTSiYpwbkyq43gGNd1coiBgI8fwjoYkj36jWanOBdjzcu2rty5oDOW30XfMzeI9NBu0zV4wvAU+O8O8c7zMD0HP3+lSGEwFu0WNtApaMx11iY3Pma5K5tYjtfxses6gsCBX1SlZzYKUpQApSlAClKUAKUpQApSlAClKUAKUpQApSlAClKUAKUpQApSlAGKVmlAClKUAKUpQApSlAClKUAKUpQApSlAH/2Q==" class="card-img-top IMGP4" alt="...">
                <div class="card-body">
                  <h5 class="card-title tituloh2 text1">PET</h5>  <br>
                  <a href="https://www.pt-mexico.com/noticias/post/guia-de-diseno-para-reciclabilidad-de-pet-ya-est-disponible-en-espanol" class="btn btn-primary boton1">ver</a>
                </div>
              </div>  
          </div>


          

        </label>

      </div>
      <div class="col-1"></div>
    </div>
  </div>



  <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="audios.js"></script>
  <?php include 'templates/footer.php' ?>

</body>

</html>