<?php
$nombre = $_GET['empresa'];
$servername = "localhost"; // Nombre del servidor de la base de datos
$username = "root"; // Nombre de usuario de la base de datos
$password = "1234"; // Contraseña de la base de datos
$dbname = "validar"; // Nombre de la base de datos

// Crear una conexión a la base de datos
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Consulta SQL para obtener la información de la empresa
$sql = "SELECT * FROM maps WHERE nombre = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $nombre);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $latitud = $row["latitud"];
    $longitud = $row["longitud"];
    $nombreEmpresa = $row["nombre"];
} else {
    die("Empresa no encontrada.");
}

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="../img/icono.png" type="imagen/x-icon">
    <title>ZDC Report | Mapa de casos</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/estilo.css">
    <!-- Incluye la biblioteca Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css">
    <style>
        #map {
            height: 656px;
            width: 80%;
            align-items: center;
        }
    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg badge nav4" ;>
    <div class="container-fluid">
    <a href="index.php"><img class="logo" src="img/ECOTEC_LOGO1.1.png" alt=""></a>
      <a class="navbar-brand nav2 letra1" href="pagina6.html">CONOCE <br>ECOTEC</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        
        <li class="nav-item">
            <a class="nav-link nav2" href="pagina3.html"> <img class="icono3" src="img\drive-download-20231016T014448Z-001\inforrmacion.png" alt=""><br></a>
          </li>

          <li class="nav-item">
            <a class="nav-link nav2" href="pagina2.html"><img class="icono3" src="img\drive-download-20231016T014448Z-001\bote.png" alt=""></a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link nav2" href="pagina5.php"> <img class="icono3" src="img\drive-download-20231016T014448Z-001\dibujoedificio1.png" alt="" >
              </a>
          </li>
          <li class="nav-item">
         
          <!-- <li class="nav-item">
            <a class="nav-link nav2" href="index.php"><img class="icono3" src="img\HOME.png" alt=""></a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link nav2" href="login.php"><img class="icono3" src="img\drive-download-20231016T014448Z-001\inicio.png" alt=""></a>
          </li>

        </ul>
      </div>
    </div>
  </nav>

    <!-- Cambia el elemento div para el mapa de Google Maps a uno compatible con Leaflet -->
    <div id="map" style="height: 656px; width: 80%;"></div>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Reemplaza el código de Google Maps con Leaflet
        var map = L.map('map').setView([<?php echo $latitud ?>, <?php echo $longitud ?>], 15);

        // Agrega una capa de mapa base de OpenStreetMap
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Agrega un marcador al mapa
        L.marker([<?php echo $latitud ?>, <?php echo $longitud ?>]).addTo(map)
            .bindPopup('<?php echo $nombreEmpresa ?>');
    </script>
    <!-- Incluye la biblioteca Leaflet -->
</body>

</html>
