<?php

include 'db.php';

sleep(1);
$id_persona = $_POST['id_persona'];
$usuario = $_POST['usuario'];

$nombre = $_POST['nombre'];
$coordenadas = $_POST['coordenadas'];
$municipio = $_POST['municipio'];
$direccion = $_POST['direccion'];
$telefono = $_POST['telefono'];

$dias_laborales = implode(", ", $_POST['dias']);

$horario = $_POST['horario'];

    $agregarempresa = mysqli_query($conexion, "INSERT INTO empresas(id_persona, usuario, nombre, coordenadas, municipio, direccion, telefono, dias_laborales, horario) 
    VALUES ('$id_persona', '$usuario', '$nombre', '$coordenadas', '$municipio', '$direccion', '$telefono', '$dias_laborales', '$horario')");
    
    if($agregarempresa){
        echo '<div class="alert alert-success" role="alert">Empresa registrada con exito</div>' ;
    }
?>

