<?php

session_start();

if(isset($_SESSION['usuario'])) {
    header("location: bienvenido.php");
}

if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "validar";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Verificar si se hizo clic en el botón de inicio de sesión
    if(isset($_POST['login'])) {
        $usuario = $_POST['usuario'];
        $contraseña = $_POST['contrasena'];

        // Consulta para buscar el usuario y contraseña en la base de datos
        $sql = "SELECT id FROM persona WHERE usuario = '$usuario' AND contrasena = '$contraseña'";
        $result = $conn->query($sql);

        if($result->num_rows == 1) {
            $_SESSION['usuario'] = $usuario;
            header("location: usuariosAdmin.php");
        } else {
            $error = "Usuario o contraseña incorrectos.";
        }
    }

    // Verificar si se hizo clic en el botón de registro
    if(isset($_POST['registro'])) {
        header("location: 002.php");
    }

    // Cerrar la conexión
    $conn->close();
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Iniciar sesión</title>
</head>
<body>

    <h2>Iniciar sesión</h2>

    <form method="post">
        <label>Usuario:</label><br>
        <input type="text" name="usuario"><br>
        <label>Contraseña:</label><br>
        <input type="password" name="contraseña"><br><br>
        <input type="submit" name="login" value="Ingresar">
        <input type="submit" name="registro" value="Registrar">
    </form>

    <?php
    if(isset($error)) {
        echo "<div style='color:red;'>".$error."</div>";
    }
    ?>

</body>
</html>
