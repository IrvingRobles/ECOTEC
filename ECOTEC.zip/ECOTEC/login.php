
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/login.css">
    <link rel="stylesheet" href="css2/bootstrap.min.css">

    <!-- <link rel="stylesheet" href="css/bootstrap.min.css"> -->
    <title>login</title>
</head>

<body>


    <div class="container text-center contenedor_login">
        <a id="zoomInButton" class="btn colorletra text1" onclick="zoomText(true)">

            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z" />
            </svg>
        </a>
        <a id="zoomOutButton" class="btn colorletra text1" onclick="zoomText(false)">

            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-out" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                <path fill-rule="evenodd" d="M3 6.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <br>
        <img src="img/ECOTEC_LOGO1.1.png" class="img1" alt="">

        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <form method="post" class="from letra1">

                    <h1 class="titulo1 text1">INICIA SESION</h1><br>
                    <p>Usuario : <input class="form-control" type="text" placeholder="ingrese su usuario" name="usuario" required> </p>
                    <p>Contraseña : <input class="form-control" type="password" placeholder="ingrese su contraseña" name="contrasena" required> </p>

                    <button class="btn btn-success" type="submit" name="login">Ingresar</button>
                    <input class="text1" class="boton" type="hidden" value="btningresar1" name="btningresar">
                </form>

                <a href="002.php" class="text1" style="text-decoration: none; color:black;">Registrate Aqui</a>

            </div>
            <div class="col-2"></div>
        </div>
    </div>



</body>


<script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>

<script src="js/bootstrap.min.js"></script>
<?php include 'templates/footer.php' ?>

</html>

<?php
session_start();

include 'db.php';

if (!empty($_POST["btningresar"])){

    // Verificar si existe una sesión de intentos de inicio de sesión
    if (!isset($_SESSION['intentos'])) {
        $_SESSION['intentos'] = 0;
    }

    // Verificar si se han realizado más de 5 intentos fallidos
    if ($_SESSION['intentos'] >= 5) {
        // Verificar si ha pasado al menos un minuto desde el último intento
        if (isset($_SESSION['ultimoIntento']) && (time() - $_SESSION['ultimoIntento'] < 30)) {
            $tiempo_restante = 30 - (time() - $_SESSION['ultimoIntento']);

            echo '<script>alert("Demasiados intentos fallidos. Por favor, inténtalo de nuevo después de: '. $tiempo_restante .' segundos")</script>';
            // echo "Demasiados intentos fallidos. Por favor, inténtalo de nuevo después de $tiempo_restante segundos.";
            exit;
        } else {
            // Reiniciar el contador de intentos
            $_SESSION['intentos'] = 0;
        }
    }

    if (!empty($_POST["usuario"]) and !empty($_POST["contrasena"])) {
        $usuario=$_POST["usuario"];
        $contrasena=$_POST["contrasena"];
        $sql= $conexion->query("SELECT * FROM persona WHERE usuario = '$usuario' AND contrasena = '$contrasena' ");
        if ($datos=$sql->fetch_object()) {
            $_SESSION["id"]=$datos->id;
            $_SESSION["usuario"]=$datos->usuario;
            $_SESSION["contrasena"]=$datos->contrasena;

            $_SESSION['intentos'] = 0;

            header("Location: usuariosAdmin.php");
        } else {
            echo '<script>alert("Credenciales incorrectas. Por favor, inténtalo de nuevo Total de Intentos: '. $_SESSION['intentos'] .'")</script>';
                // echo "Credenciales incorrectas. Por favor, inténtalo de nuevo.";
                // Incrementar el contador de intentos fallidos
                $_SESSION['intentos']++;
                // Actualizar el tiempo del último intento fallido
                $_SESSION['ultimoIntento'] = time();

                // Mostrar el total de intentos fallidos
                // echo "<br>Total de intentos fallidos: " . $_SESSION['intentos'];
        }
        
    } else {
        echo "campos vacios";
    }
    
    
}
?>