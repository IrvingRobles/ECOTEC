<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/login.css">
    <script src="js/jquery.min.js"></script>
    <title>Registro</title>
    <script>
        $(document).ready(function() {
            $('#enviarcorreo').submit(function(e) {
                e.preventDefault();

                document.getElementById("mensajecorreo").innerHTML = "";
                var Btnregistro = $("#Btnregistro");
                $.ajax({
                    data: $('#enviarcorreo').serialize(),
                    url: 'correo.php',
                    type: 'post',
                    beforeSend: function() {
                        $("#Btnregistro").text("Registrando...");
                    },
                    complete: function(data) {
                        var resp = data.responseText;
                        Btnregistro.text("Registrate");
                    },
                    success: function(respuesta) {
                        setTimeout(function() {
                            document.getElementById('resultadocorreo').style.display = 'none';
                        }, 2000);
                        document.getElementById('resultadocorreo').style.display = 'block';
                        // document.getElementById("mensajecorreo").innerHTML = '<div class="alert alert-success alert-dismissible alertas"><strong>Exito!</strong>Tu perfil a sido modificado</div> </div>';
                        $('#mensajecorreo').html(respuesta);
                    },
                });
            });
        });
    </script>
    
</head>

<body>

    <div class="container text-center contenedor_login">
        <a id="zoomInButton" class="btn colorletra text1" onclick="zoomText(true)">

            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-in" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                <path fill-rule="evenodd" d="M6.5 3a.5.5 0 0 1 .5.5V6h2.5a.5.5 0 0 1 0 1H7v2.5a.5.5 0 0 1-1 0V7H3.5a.5.5 0 0 1 0-1H6V3.5a.5.5 0 0 1 .5-.5z" />
            </svg>
        </a>
        <a id="zoomOutButton" class="btn colorletra text1" onclick="zoomText(false)">

            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-zoom-out" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11zM13 6.5a6.5 6.5 0 1 1-13 0 6.5 6.5 0 0 1 13 0z" />
                <path d="M10.344 11.742c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1 6.538 6.538 0 0 1-1.398 1.4z" />
                <path fill-rule="evenodd" d="M3 6.5a.5.5 0 0 1 .5-.5h6a.5.5 0 0 1 0 1h-6a.5.5 0 0 1-.5-.5z" />
            </svg>
        </a>
        <br>
        <img src="img/ECOTEC_LOGO1.1.png" class="img1" alt="">

        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <form id="enviarcorreo" class="from letra1">

                    <h1 class="titulo1 text1">Registro</h1><br>
                    <p>Nombre Completo: <input class="form-control" type="text" placeholder="Ingrese su Nombre" name="nombre" required> </p>
                    <p>Usuario : <input class="form-control" type="text" placeholder="Ingrese su usuario" name="usuario" required> </p>
                    <p>Correo : <input class="form-control" type="email" placeholder="Ingrese su Correo" name="correo" required> </p>
                    <p>Contraseña : <input class="form-control" type="password" pattern="^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[^\w\d\s])\S{10,}$" title="Formato novalido Ejemplo: Ecotec002$ con 10 caracteres" maxlength="10" placeholder="Ingrese su contraseña Ejemplo: Ecotec002$" name="contrasena" required> </p>

                    <button class="btn btn-success" type="submit" id="Btnregistro" name="login">Registrate</button>
                    <input class="text1" class="boton" type="hidden" value="btningresar1" name="btningresar">

                    <!-- ALERTA DE CORREO -->
                    <div id="resultadocorreo" style="display:none;">
                        <div id="mensajecorreo"></div>
                    </div>
                </form>

                <a href="login.php" class="text1" style="text-decoration: none; color:black;">Iniciar Sesión</a>

            </div>
            <div class="col-2"></div>
        </div>
    </div>


</body>
<script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>

<script src="js/bootstrap.min.js"></script>
<script src="js/hacerzoom.js"></script>

</html>