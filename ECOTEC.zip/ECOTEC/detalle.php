<?php
include 'db.php';

// Obtener el ID de la empresa desde la URL
if (isset($_GET['id'])) {
    $empresa_id = $_GET['id'];
} else {
    die("ID de empresa no especificado.");
}

// Consulta SQL para obtener información de la empresa seleccionada
$sql_empresa = "SELECT * FROM empresas WHERE id = $empresa_id";
$result_empresa = $conexion->query($sql_empresa);

// Verificar si la empresa existe
if ($result_empresa->num_rows == 0) {
    die("Empresa no encontrada.");
}

$empresa = $result_empresa->fetch_assoc();

// Consulta SQL para obtener los productos de la empresa
$sql_productos = "SELECT * FROM productos WHERE empresa_id = $empresa_id";
$result_productos = $conexion->query($sql_productos);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/estilo.css">
    <link rel="stylesheet" href="css2/detalle.css">
    <title>Detalles de <?php echo $empresa['nombre']; ?></title>
    <!-- Incluir estilos de Leaflet -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
  <style>
    #map {
      height: 600px;
      width: 100%;
    }
  </style>
</head>

<body class="bodyp">
  <?php include 'templates/header.php' ?>



    <div class="container text-center">

        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <label for="" class="label1">
                    <h2 class="tituloh2 text1">Detalles de <?php echo $empresa['nombre']; ?></h2>

                    <div class="company-box">
                        <h2 class="tituloh2 text1">Información de la Empresa:</h2>
                        <p class="text1"><strong>Nombre:</strong> <?php echo $empresa['nombre']; ?></p>
                        <p class="text1"><strong>Municipio:</strong> <?php echo $empresa['municipio']; ?></p>
                        <p class="text1"><strong>Dirección:</strong> <?php echo $empresa['direccion']; ?></p>
                        <p class="text1"><strong>Teléfono:</strong> <?php echo $empresa['telefono']; ?></p>
                        <p class="text1"><strong>Días Laborales:</strong> <?php echo $empresa['dias_laborales']; ?></p>
                        <p class="text1"><strong>Horario:</strong> <?php echo $empresa['horario']; ?></p>
                    </div>
                    <div class="company-box">
                        <h2 class="tituloh2 text1">Productos:</h2>
                        <?php
                        if ($result_productos->num_rows > 0) {
                            echo "<ul>";
                            while ($producto = $result_productos->fetch_assoc()) {
                                echo "<li>" . $producto["nombre"] . " - Precio x kilogramo: " . $producto["precio"] . "</li>";
                            }
                            echo "</ul>";
                        } else {
                            echo "<p class='text1'>Esta empresa no tiene productos registrados.</p>";
                        }
                        ?>
                    </div>
                    <div class="company-box">
                        <h3 style="text-align: center;">Localización</h3>
                        <div id="map"></div>

                    </div>

                    

                    <div class="clearfix"></div>

                    <a class="back-button text1" href="pagina5.php">Volver a la lista de empresas</a>
                </label>
            </div>
            <div class="col-2"></div>
        </div>
    </div>

    <div class="position-absolute bottom-0 start-0">
    </div>

    <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
  var map = L.map('map').setView([<?php echo $empresa['coordenadas']; ?>], 13);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
  }).addTo(map);

  L.marker([<?php echo $empresa['coordenadas']; ?>]).addTo(map)
    .bindPopup('Coordenadas: <?php echo $empresa['coordenadas']; ?>')
    .openPopup();
</script>

    <?php include 'templates/footer.php' ?>

</body>

</html>
<?php
// Cerrar la conexión a la base de datos
$conexion->close();
?>