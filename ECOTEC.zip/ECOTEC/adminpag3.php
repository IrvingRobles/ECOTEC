<?php include 'sesiones.php'; ?>
<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
  <link rel="stylesheet" href="css2/estilo.css">
  <title> >DATOS DE RECICLAJE DE BASURA DOMÉSTICOS</title>
</head>

<body class="bodyp">
<?php include 'templates/header2.php' ?>


  <div class="container text-center">

    <div class="row">
      <div class="col-2"></div>
      <div class="col-8">
        <h2 class="tituloh2 text1">DATOS DE RECICLAJE DE BASURA DOMÉSTICOS</h2>
        <label for="" class="label1">
          <img src="img/2.jpeg" class="IMGP2" alt="">

          <div>
            <h5 class="h5 text1">Certificación y control de envases domésticos <br> recogidos y reciclados
            </h5>
            <label for="" class="label1 text1">
              El ciclo del reciclaje es un proceso constantemente controlado de principio a fin.
              Todos los controles de trazabilidad que respaldan esta actividad diaria lo llevan a cabo
              empresas auditoras externas a Ecotec, que garantizan la transformación del residuo en un
              nuevo recurso.
              Aquí te explicamos qué controles se realizan a lo largo del ciclo del reciclaje y quiénes
              los llevan a cabo.

            </label>
            <button type="button" class="nav2" style="border: none;" onclick="sound5.play()"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" fill="currentColor" class="bi bi-volume-up-fill" viewBox="0 0 16 16">
                <path d="M11.536 14.01A8.473 8.473 0 0 0 14.026 8a8.473 8.473 0 0 0-2.49-6.01l-.708.707A7.476 7.476 0 0 1 13.025 8c0 2.071-.84 3.946-2.197 5.303l.708.707z" />
                <path d="M10.121 12.596A6.48 6.48 0 0 0 12.025 8a6.48 6.48 0 0 0-1.904-4.596l-.707.707A5.483 5.483 0 0 1 11.025 8a5.483 5.483 0 0 1-1.61 3.89l.706.706z" />
                <path d="M8.707 11.182A4.486 4.486 0 0 0 10.025 8a4.486 4.486 0 0 0-1.318-3.182L8 5.525A3.489 3.489 0 0 1 9.025 8 3.49 3.49 0 0 1 8 10.475l.707.707zM6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z" />
              </svg></button>
          </div>

          <h5 class="h5">Proceso</h5>
          <label for="" class="label1 text1">
            1. Información mensual sobre cantidades recogidas, seleccionadas y recicladas. Cada mes las administraciones públicas (empresas) reportan a través de la página web la información exacta de las recogidas de los envases, precios de compra o venta, intercambios que dan por el reciclado, entre otros. <br>
            <br>
            2. Validación de información y confirmación del cumplimiento de los convenios. Varias veces al mes diferentes empresas externas verifican y validan que la información proporcionada por las administraciones públicas sobre los diferentes precios que ofrecen, el tipo de reciclaje que compran o buscan y los lugares donde ir a dejarlos sean correctos. <br> <br>
            3. Análisis e identificación de los residuos. Las empresas analizan los tipos de materiales que el ciudadano o administración pública desea vender. Verifican si es lo que buscan o no. <br> <br>
            4. Control de calidad de los residuos (GIRSU). Estos controles sirven para asegurar que el material que sale de las plantas de selección, y cuyo siguiente destino serán ya las plantas recicladoras, cumple con las especificaciones técnicas recogidas tanto en los convenios que se firma con la administración pública como en los contratos que GIRSU maneja.
            <button type="button" class="nav2" style="border: none;" onclick="sound6.play()"><svg xmlns="http://www.w3.org/2000/svg" width="37" height="37" fill="currentColor" class="bi bi-volume-up-fill" viewBox="0 0 16 16">
                <path d="M11.536 14.01A8.473 8.473 0 0 0 14.026 8a8.473 8.473 0 0 0-2.49-6.01l-.708.707A7.476 7.476 0 0 1 13.025 8c0 2.071-.84 3.946-2.197 5.303l.708.707z" />
                <path d="M10.121 12.596A6.48 6.48 0 0 0 12.025 8a6.48 6.48 0 0 0-1.904-4.596l-.707.707A5.483 5.483 0 0 1 11.025 8a5.483 5.483 0 0 1-1.61 3.89l.706.706z" />
                <path d="M8.707 11.182A4.486 4.486 0 0 0 10.025 8a4.486 4.486 0 0 0-1.318-3.182L8 5.525A3.489 3.489 0 0 1 9.025 8 3.49 3.49 0 0 1 8 10.475l.707.707zM6.717 3.55A.5.5 0 0 1 7 4v8a.5.5 0 0 1-.812.39L3.825 10.5H1.5A.5.5 0 0 1 1 10V6a.5.5 0 0 1 .5-.5h2.325l2.363-1.89a.5.5 0 0 1 .529-.06z" />
              </svg></button>
          </label>

        </label>
      </div>
      <div class="col-2"></div>
    </div>
  </div>



  <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="audios.js"></script>
  <?php include 'templates/footer.php' ?>

</body>

</html>