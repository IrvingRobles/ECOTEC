<?php
// Verificar si se ha recibido el id de la empresa a editar
if (isset($_GET["id"])) {
    $idEmpresa = $_GET["id"];

    // Conexión a la base de datos
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "validar";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Conexión fallida: " . $conn->connect_error);
    }

    // Consulta para obtener los datos de la empresa correspondiente
    $sql = "SELECT * FROM listaempresas WHERE idEmpresa = $idEmpresa";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nombre = $row["nombre"];
        $direccion = $row["direccion"];
        $ciudad = $row["ciudad"];
        $horarioAtencion = $row["horarioAtencion"];
        $correo = $row["correo"];
        $telefono = $row["telefono"];
    } else {
        echo "No se encontraron resultados.";
        exit;
    }

    // Cerrar la conexión
    $conn->close();

} else {
    echo "No se ha especificado el id de la empresa a editar.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="fontawesome-free-6.3.0-web/css/all.min.css">
    <link rel="stylesheet" href="css2/estilo.css">
    <title>EDITAR</title>
</head>

<body class="bodyp">
  <nav class="navbar navbar-expand-lg badge nav4" ;>
    <div class="container-fluid">
      <a class="navbar-brand nav2" href="adminpag6.html">CONOCE Ecotec</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">


          <li class="nav-item">
            <a class="nav-link nav2" href="adminpag2.html">EL PROCESO DEL <br> RECICLAJE</a>
          </li>
          <li class="nav-item">
            <a class="nav-link nav2" href="adminpag3.html">DATOS DE RECICLAJE DE <br> BASURA DOMÉSTICOS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link nav2" href="adminpag4.html">REGISTRA MI EMPRESA</a>
          </li>
          <li class="nav-item">
            <a class="nav-link nav2" href="adminpag5.php"><i class="fa-solid fa-building icono2"></i> <br>
              EMPRESAS</a>
          </li>
          <li class="nav-item">
          <li class="nav-item">
            <a class="nav-link nav2" href="adminpag7.html"> <i class="fa-solid fa-recycle icono2"></i><br>
              RECICLADORES Y RECOGIDAS FUERA DEL HOGAR</a>
          </li>
          <li class="nav-item">
            <a class="nav-link nav2" href="usuariosAdmin.php"><i class="fa-solid fa-home-user"></i> <br> INICIO</a>
          </li>
         

        </ul>
      </div>
    </div>
  </nav>
    
    <div class="container text-center">

        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <h2 class="tituloh2"></h2>
                <label for="" class="label1">

                <h2>Editar empresa</h2>
                <?php
// Conectar a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "validar";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener el ID de la empresa a editar
$id = $_GET["id"];

// Obtener los datos de la empresa a partir del ID
$sql = "SELECT * FROM listaempresas WHERE idEmpresa = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

// Mostrar un formulario para editar los datos de la empresa
echo "<form action='guardar.php' method='post'>
      <input type='hidden' name='id' value='".$row["idEmpresa"]."'>
      <label for='nombre'>Nombre de la empresa:</label>
      <input type='text' name='nombre' value='".$row["nombre"]."'><br>
      <label for='direccion'>Dirección:</label>
      <input type='text' name='direccion' value='".$row["direccion"]."'><br>
      <label for='ciudad'>Ciudad:</label>
      <input type='text' name='ciudad' value='".$row["ciudad"]."'><br>
      <label for='horario'>Horario de atención:</label>
      <input type='text' name='horario' value='".$row["horarioAtencion"]."'><br>
      <label for='correo'>Correo:</label>
      <input type='email' name='correo' value='".$row["correo"]."'><br>
      <label for='telefono'>Teléfono:</label>
      <input type='text' name='telefono' value='".$row["telefono"]."'><br>
      <input type='submit' value='Guardar'>
      </form>";

// Cerrar la conexión
$conn->close();
?>

                    
                </label>
            </div>
            <div class="col-2"></div>
        </div>
    </div>

    <div class="position-absolute bottom-0 start-0">
        <button type="button" class="btn btn-light"><a href="index.html" class=" btnR">Regresar</a></button>
    </div>

    <script src="fontawesome-free-6.3.0-web/js/all.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>


    